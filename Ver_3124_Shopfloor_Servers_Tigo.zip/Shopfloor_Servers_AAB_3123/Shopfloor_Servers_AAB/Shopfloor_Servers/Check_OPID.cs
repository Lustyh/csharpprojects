﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json.Linq;

namespace Shopfloor_Servers
{
    class Check_OPID
    {
        private static string File_Path = "", File_Nmae = "//UserInfo.txt";
        public static JObject all_User;
        /// <summary>
        /// Init Check_OPID class,and get UserInfo config
        /// </summary>
        public static void Init_CheckOPID()
        {
            File_Path = GetConfigValue.UserID_Path;
            try
            {
                if (!Directory.Exists(File_Path))
                {
                    Directory.CreateDirectory(File_Path);
                }
                if (!File.Exists(File_Path + File_Nmae))
                {
                    Write_File("{\"A7340231\":{\"Password\": \"" + RecordLog.NomalCreatMD5("12345") + "\",\"UserType\":\"ENGINEER\"}}");
                }
            }
            catch (Exception)
            {
            }
            upload();
        }
        /// <summary>
        /// read UserInfo config
        /// </summary>
        /// <returns></returns>
        public static JObject Read_File()
        {
            return JObject.Parse(File.ReadAllText(File_Path + File_Nmae));
        }
        /// <summary>
        /// upload UserInfo config
        /// </summary>
        /// <param name="Userinfo"> UserInfo content</param>
        public static void Write_File(string Userinfo)
        {
            try
            {
                StreamWriter streamWriter = new StreamWriter(File_Path + File_Nmae, false);
                streamWriter.Write(Userinfo);
                streamWriter.Close();
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// add new user
        /// </summary>
        /// <param name="user_id">userid</param>
        /// <param name="password">password</param>
        /// <param name="user_type">permission type</param>
        /// <returns> result </returns>
        public static string[] Add_user(string user_id, string password, string user_type)
        {
            string[] response = { "PASS", "OK" };
            user_id = user_id.Substring(3);
            user_type = get_permission(user_type);
            try
            {
                JObject now_user = Read_File();
                if (now_user.ContainsKey(user_id))
                {
                    response[0] = "FAIL"; response[1] = "User ID already exist";
                    return response;
                }
                now_user.Add(user_id, JObject.Parse("{\"Password\": \""+ RecordLog.NomalCreatMD5(password) + "\", \"UserType\": \""+user_type+"\"}"));
                Write_File(now_user.ToString()); upload();
            }
            catch (Exception Add_error)
            {
                response[0] = "FAIL";response[1] = Add_error.Message.ToString();
            }
            return response;
        }

        /// <summary>
        /// upload user info about user's passoword permission
        /// </summary>
        /// <param name="user_id">User_id</param>
        /// <param name="password">password</param>
        /// <param name="user_type">permission</param>
        /// <returns>result</returns>
        public static string[] Update_user(string user_id, string password, string user_type)
        {
            string[] response = { "PASS", "OK" };
            user_id = user_id.Substring(3);
            user_type = get_permission(user_type);
            try
            {
                JObject now_user = Read_File();
                if (!now_user.ContainsKey(user_id))
                {
                    response[0] = "FAIL"; response[1] = "User ID don't exist";
                    return response;
                }
                now_user.Remove(user_id);
                now_user.Add(user_id, JObject.Parse("{\"Password\": \""+ RecordLog.NomalCreatMD5(password) + "\", \"UserType\": \""+user_type+"\"}"));
                Write_File(now_user.ToString()); upload();
            }
            catch (Exception Add_error)
            {
                response[0] = "FAIL"; response[1] = Add_error.Message.ToString();
            }
            return response;
        }

        /// <summary>
        /// Delete User 
        /// </summary>
        /// <param name="user_id">user_id</param>
        /// <param name="password">password</param>
        /// <param name="user_type">permission</param>
        /// <returns></returns>
        public static string[] Delete_user(string user_id, string password, string user_type)
        {
            string[] response = { "PASS", "OK" };
            user_id = user_id.Substring(3);
            user_type = get_permission(user_type);
            try
            {
                JObject now_user = Read_File();
                if (!now_user.ContainsKey(user_id))
                {
                    response[0] = "FAIL"; response[1] = "User ID don't exist";
                    return response;
                }
                now_user.Remove(user_id);
                Write_File(now_user.ToString()); upload();
            }
            catch (Exception Add_error)
            {
                response[0] = "FAIL"; response[1] = Add_error.Message.ToString();
            }
            return response;
        }

        /// <summary>
        /// QueryUser
        /// </summary>
        /// <returns></returns>
        public static string[] Query_User()
        {
            string[] response = { "PASS", Read_File().ToString() };
            return response;
        }

        /// <summary>
        /// translate permission
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private static string get_permission(string type)
        {
            switch (type)
            {
                case "1":
                    return "ENGINEER";
                case "2":
                    return "MAINTAINER";
                case "3":
                    return "TECHNICIAN";
                default:
                    return "OPERATOR";
            }
        }

        /// <summary>
        /// read UserInfo config to upload all_user 
        /// </summary>
        private static void upload()
        {
            all_User = Read_File();
        }

        /// <summary>
        /// Check user's permission
        /// </summary>
        /// <param name="user_id">user_id</param>
        /// <param name="password">password</param>
        /// <returns>result</returns>
        public static string[] Check_User(string user_id, string password)
        {
            string[] response = { "FAIL", "" };
            try
            {

                if (!all_User.ContainsKey(user_id))
                {
                    response[0] = "FAIL"; response[1] = "";
                }
                else
                {
                    //JObject user_info = JObject.Parse(all_User.GetValue(user_id).ToString());
                    if (((JObject)all_User.GetValue(user_id)).GetValue("Password").ToString() != RecordLog.NomalCreatMD5(password))
                    {
                        response[0] = "FAIL1"; response[1] = "Password is wrong";
                    }
                    else
                    {
                        response[0] = "PASS"; response[1] = ((JObject)all_User.GetValue(user_id)).GetValue("UserType").ToString();
                    }
                }
            }
            catch (Exception check_usererror)
            {
                response[0] = "FAIL1"; response[1] = check_usererror.Message;
            }
            return response;
        }
    }
}
