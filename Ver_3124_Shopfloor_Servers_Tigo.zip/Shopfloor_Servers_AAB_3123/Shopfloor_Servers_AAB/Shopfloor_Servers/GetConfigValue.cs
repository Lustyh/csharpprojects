﻿using Ini;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shopfloor_Servers
{
    class GetConfigValue
    {
        static IniFile Getiniinfo = new IniFile(System.Environment.CurrentDirectory + "\\Clifford-SF.ini");
        public static string SMT_DBname, SMT_DBserver, FATP_DBname, FATP_DBserver1, FATP_DBserver2, FATP_DBserver1_BK, FATP_DBserver2_BK, FATP_Interface1, FATP_Interface2, SMT_Interface;
        public static string FATP_dummy_sn_scof, FATP_dummy_sn, SMT_dummy_sn, SMT_dummy_sn_scof, FATP_dummy_sn_build_phase, SMT_dummy_sn_build_phase, BU10_dummy_sn;
        public static string[] Check_AAB, Check_ABC;
        public static string LogPath, Fail_Item_Path, Fail_FPY_Path, UserID_Path;
        public static string[] UploadStations, SMT_Stations, QAStations, BU10Projects, BU10UploadStations;
        public static string SWDBIP, SWdatabase, DBStatus;

        /// <summary>
        /// Get public config
        /// </summary>
        public static void ConfigInit()
        {
            SMT_DBname = Getiniinfo.IniReadValue("SMT", "DBname");
            SMT_DBserver = Getiniinfo.IniReadValue("SMT", "DBserver");
            SMT_Stations = Getiniinfo.IniReadValue("SMT", "Station").Split(';');
            SMT_Interface = Getiniinfo.IniReadValue("SMT", "Interface");
            BU10UploadStations = Getiniinfo.IniReadValue("SMT", "BU10UploadStation").Split(';');

            FATP_DBname = Getiniinfo.IniReadValue("FATP", "DBname");
            FATP_DBserver1 = Getiniinfo.IniReadValue("FATP", "DBserver1");
            FATP_DBserver1_BK = Getiniinfo.IniReadValue("FATP", "DBserver1_BK");
            FATP_DBserver2 = Getiniinfo.IniReadValue("FATP", "DBserver2");
            FATP_DBserver2_BK = Getiniinfo.IniReadValue("FATP", "DBserver2_BK");
            FATP_Interface1 = Getiniinfo.IniReadValue("FATP", "Interface1");
            FATP_Interface2 = Getiniinfo.IniReadValue("FATP", "Interface2");
            UploadStations = Getiniinfo.IniReadValue("FATP", "UploadStation").Split(';');

            SMT_dummy_sn = Getiniinfo.IniReadValue("DUMMY", "SMT_SN");
            SMT_dummy_sn_scof = Getiniinfo.IniReadValue("DUMMY", "SMT_SCOF");
            SMT_dummy_sn_build_phase = Getiniinfo.IniReadValue("DUMMY", "SMT_SKU");

            FATP_dummy_sn = Getiniinfo.IniReadValue("DUMMY", "FATP_SN");
            FATP_dummy_sn_scof = Getiniinfo.IniReadValue("DUMMY", "FATP_SCOF");
            FATP_dummy_sn_build_phase = Getiniinfo.IniReadValue("DUMMY", "FATP_SKU");

            BU10_dummy_sn = Getiniinfo.IniReadValue("DUMMY", "BU10_SN");

            LogPath = Getiniinfo.IniReadValue("PATH", "LogPath");
            Fail_Item_Path = Getiniinfo.IniReadValue("PATH", "FailItemPath");
            Fail_FPY_Path = Getiniinfo.IniReadValue("PATH", "FailFPYPath");
            UserID_Path = Getiniinfo.IniReadValue("PATH", "UserIDPath");

            Check_AAB = Getiniinfo.IniReadValue("RULE", "AAB").Split(';');
            Check_ABC = Getiniinfo.IniReadValue("RULE", "ABC").Split(';');


            SWDBIP = Getiniinfo.IniReadValue("SWDB", "IP");
            SWdatabase = Getiniinfo.IniReadValue("SWDB", "DataBase");
            DBStatus = Getiniinfo.IniReadValue("SWDB", "Status").ToUpper();
            /*Console.WriteLine("SMT_DBname:{0},SMT_DBserver:{1}, SMT_Stations:{2}, SMT_Interface:{3}，FATP_DBname:{4}, FATP_DBserver1:{5}, FATP_DBserver1_BK:{6}, FATP_DBserver2:{7}, FATP_DBserver2_BK:{8}, FATP_Interface1:{9}, FATP_Interface2:{10}, ",
                                SMT_DBname, SMT_DBserver, list_str(SMT_Stations), SMT_Interface, FATP_DBname, FATP_DBserver1, FATP_DBserver1_BK, FATP_DBserver2, FATP_DBserver2_BK, FATP_Interface1, FATP_Interface2);

            Console.WriteLine("UploadStations:{0},SMT_dummy_sn:{1}, SMT_dummy_sn_scof:{2}, SMT_dummy_sn_build_phase:{3}，FATP_dummy_sn:{4}, FATP_dummy_sn_scof:{5}, FATP_dummy_sn_build_phase:{6}, Check_AAB:{7}, Check_ABC:{8}, LogPath:{9}, Fail_Item_Path:{10},Fail_FPY_Path:{11}, ",
                        list_str(UploadStations), SMT_dummy_sn, SMT_dummy_sn_scof, SMT_dummy_sn_build_phase, FATP_dummy_sn, FATP_dummy_sn_scof, FATP_dummy_sn_build_phase, list_str(Check_AAB), list_str(Check_ABC), LogPath, Fail_Item_Path, Fail_FPY_Path);
            */
            QAStations = Getiniinfo.IniReadValue("QAStations", "Stations").Split(';');
            BU10Projects = Getiniinfo.IniReadValue("BU10Projects", "Projects").Split(';');
        }

        private static string list_str(string[] list_)
        {
            string str = "";
            for (int i = 0; i < list_.Length; i++)
            {
                str += list_[i]+":";
            }
            return str;
        }

        /// <summary>
        /// GET service IP
        /// </summary>
        /// <returns> return IP from config </returns>
        public static string GetIP()
        {
            return Getiniinfo.IniReadValue("SERVER", "IP");
        }

        /// <summary>
        /// Get service Port
        /// </summary>
        /// <returns> return port from config </returns>
        public static string GetPort()
        {
            return Getiniinfo.IniReadValue("SERVER", "PORT");
        }
        /// <summary>
        /// Get SCOF status
        /// </summary>
        /// <param name="project"> request project id </param>
        /// <returns> return SCOF status from config </returns>
        public static string GetSCOF(string project)
        {
            return Getiniinfo.IniReadValue("SCOF", project.ToUpper());
        }
        /// <summary>
        /// Get COF Satus
        /// </summary>
        /// <param name="project">project</param>
        /// <returns>return COF status from config</returns>
        public static string GetCOF(string project)
        {
            return Getiniinfo.IniReadValue("COF", project.ToUpper());
        }
        /// <summary>
        /// Get retest policy
        /// </summary>
        /// <param name="project">project</param>
        /// <returns>return retest policy status from config</returns>
        public static string GetRetestRule(string project)
        {
            return Getiniinfo.IniReadValue("RULE", project.ToUpper());
        }
        /// <summary>
        /// Get Assembly keys
        /// </summary>
        /// <param name="project"> request project id </param>
        /// <returns> return Assembly keys from config </returns>
        public static string GetAssembly(string project)
        {
            return Getiniinfo.IniReadValue("ASSEMBLY", project.ToUpper());
        }
        /// <summary>
        /// SMT true fail project
        /// </summary>
        /// <returns></returns>
        public static string GetSMTTrueFAILPro()
        {
            return GetConfigValue.Getiniinfo.IniReadValue("SMT", "Project");
        }
        /// <summary>
        /// Get AAB test rule by project to query station/line
        /// </summary>
        /// <param name="Project"></param>
        /// <returns></returns>
        public static string GetAABReTestRule(string Project)
        {
            return GetConfigValue.Getiniinfo.IniReadValue("AAB", Project);
        }
        /// <summary>
        /// Get AAB test rule by project to query station/line
        /// </summary>
        /// <param name="Project"></param>
        /// <returns></returns>
        public static string GetABCReTestRule(string Project)
        {
            return GetConfigValue.Getiniinfo.IniReadValue("ABC", Project);
        }
        /// <summary>
        /// Get BU10 upload statons' variables
        /// </summary>
        /// <param name="Project"></param>
        /// <param name="Station"></param>
        /// <returns></returns>
        public static string[] GetUploadBU10Variables(string Project,string Station)
        {
            string[] Variables = { "" };
            try
            {
                //Console.WriteLine("line 167 [project_station]: {0}", Project.ToUpper() + "_" + Station.ToUpper());
                Variables = GetConfigValue.Getiniinfo.IniReadValue("BU10Projects", Project.ToUpper() + "_" + Station.ToUpper()).Split(';');
                return Variables;
            }
            catch(Exception e)
            {
                Console.WriteLine("[GetUploadBU10Variables error]: {0}",e.Message);
            }
            return Variables;
        }
    }
}
