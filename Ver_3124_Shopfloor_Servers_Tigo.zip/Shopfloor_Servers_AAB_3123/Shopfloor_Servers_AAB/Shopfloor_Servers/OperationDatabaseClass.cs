﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace Shopfloor_Servers
{
    public class OperationDatabaseClass
    {
        // string constr = @"Data Source=.;user id=DESKTOP-S5TCPLT\Simple;Initial Catalog=SSCIM;Integrated Security=True";
        // public SqlConnection eSqlConnection = new SqlConnection("Data Source=.;Initial Catalog=Student;Integrated Security=True");
        //public static SqlConnection eSqlConnection; //= new SqlConnection(@"Server=" + GetConfigValue.SWDBIP + ";user=sa;pwd=QCMC+selsw;database=" + GetConfigValue.SWdatabase + ";Integrated Security=False");

        //public static SqlCommand eSqlCommand; //= new SqlCommand();

        public static string eSqlString = null;

        public static string InsertString = null;

        public static string UpdateString = null;

        public static string ProjectString = null;

        public static string WhereString = null;

        public static DataSet eDataSet;

        public static DataView eDataView;

        public static void InitSWDatabass()
        {
           
            eDataSet = new DataSet();
            eDataView = new DataView();
        }
        public static string Insert(string TableName, string TableIDValue, string InsertValue)
        {
            string ResultString = null;
            //string strcon = "Server="+ GetConfigValue.SWDBIP + ";Database=" + GetConfigValue.SWdatabase + ";Persist Security Info=False;User ID=sa; Password=QCMC+selsw;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30";
            SqlConnection eSqlConnection = new SqlConnection(@"Server=" + GetConfigValue.SWDBIP + ";user=sa;pwd=QCMC+selsw;database=" + GetConfigValue.SWdatabase + ";Integrated Security=False");
            //SqlConnection eSqlConnection = new SqlConnection(strcon); //+ ";Integrated Security=False"
            eSqlConnection.Open();
            SqlCommand eSqlCommand = new SqlCommand();
            eSqlCommand.Connection = eSqlConnection;
            try
            {
                //eSqlCommand.Connection = eSqlConnection;
                if (TableIDValue != "")
                {
                    eSqlCommand.CommandText = "select * from " + TableName + " where " + TableIDValue;
                    if (eSqlCommand.ExecuteScalar() == null)
                    {
                        eSqlCommand.CommandText = "insert into " + TableName + " values " + InsertValue;
                        eSqlCommand.ExecuteNonQuery();
                        ResultString = "新信息添加成功！";
                    }
                    else
                    {
                        ResultString = "ID信息已经存在！";
                    }
                }//单个插入记录
                else
                {
                    eSqlCommand.CommandText = "insert into " + TableName + " values " + InsertValue;
                    eSqlCommand.ExecuteNonQuery();
                    ResultString = "新信息添加成功！";
                }
            }
            catch (Exception ex)
            {
                ResultString = ex.Message.ToString() + "     数据添加操作失败!";
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + ex.Message);
            }
            eSqlConnection.Close();
            return ResultString;
        }


        /// <summary>
        /// 取得当前源码的哪一行
        /// </summary>
        /// <returns></returns>
        private static int GetLineNum()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileLineNumber();
        }
        /// <summary>
        /// 取当前源码的源文件名
        /// </summary>
        /// <returns></returns>
        private static string GetCurSourceFileName()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileName();
        }
        /*public static string Update(string TableName, string WhereString, string UpdateString, bool SingleUpdate)
        {
            string ResultString = null;
            eSqlConnection.Open();
            try
            {
                eSqlCommand.Connection = eSqlConnection;
                if (WhereString != "")
                {
                    eSqlCommand.CommandText = "update " + TableName + " set " + UpdateString + " where " + WhereString;
                }//单次更新
                else
                {
                    eSqlCommand.CommandText = "update " + TableName + " set " + UpdateString;
                }//批量更新
                eSqlCommand.ExecuteNonQuery();
                if (SingleUpdate)
                {
                    ResultString = "修改操作成功！";
                }
            }
            catch (Exception ex)
            {
                ResultString = ex.Message.ToString() + WhereString + "     数据库更新操作失败!";
            }
            eSqlConnection.Close();
            return ResultString;
        }
        public static DataView Query(string TableName, string ProjectionString, string WhereString)
        {
            eSqlConnection.Open();
            if (WhereString == "")
            {
                eSqlString = "select " + ProjectionString + " from " + TableName;
            }
            else
            {
                eSqlString = "select " + ProjectionString + " from " + TableName + " where " + WhereString;
            }
            SqlDataAdapter eSqlDataAdapter = new SqlDataAdapter(eSqlString, eSqlConnection);
            eDataSet.Tables.Clear();
            eDataSet.Clear();
            eSqlDataAdapter.Fill(eDataSet, TableName);
            eSqlConnection.Close();
            eDataSet.Tables[TableName].DefaultView.AllowNew = false;
            return eDataSet.Tables[TableName].DefaultView;
        }
        public static string Delete(string TableName, string DeleteString)
        {
            string ResultString = null;
            eSqlConnection.Open();
            try
            {
                eSqlCommand.Connection = eSqlConnection;
                eSqlCommand.CommandText = "delete  from " + TableName + " where " + DeleteString;
                eSqlCommand.ExecuteNonQuery();
                ResultString = "删除操作成功！";
            }
            catch (Exception ex)
            {

                ResultString = ex.Message.ToString() + "     数据库删除操作失败!";
            }
            eSqlConnection.Close();
            return ResultString;
        }*/

    }
}