﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace Shopfloor_Servers
{
    public class OperationDatabaseClass
    {
        // string constr = @"Data Source=.;user id=DESKTOP-S5TCPLT\Simple;Initial Catalog=SSCIM;Integrated Security=True";
        // public SqlConnection eSqlConnection = new SqlConnection("Data Source=.;Initial Catalog=Student;Integrated Security=True");
        public SqlConnection eSqlConnection = new SqlConnection(@"Server=10.17.79.76;user=sa;pwd=sa;database=QCMC_PU4_SW;IntegratedSecurity=false");

        public SqlCommand eSqlCommand = new SqlCommand();
        
        public string eSqlString = null;

        public string InsertString = null;

        public string UpdateString = null;

        public string ProjectString = null;

        public string WhereString = null;

        public DataSet eDataSet = new DataSet();

        public DataView eDataView = new DataView();
        public string Insert(string TableName, string TableIDValue, string InsertValue)
        {
            string ResultString = null;
            eSqlConnection.Open();
            try
            {
                eSqlCommand.Connection = eSqlConnection;
                if (TableIDValue != "")
                {
                    eSqlCommand.CommandText = "select * from " + TableName + " where " + TableIDValue;
                    if (eSqlCommand.ExecuteScalar() == null)
                    {
                        eSqlCommand.CommandText = "insert into " + TableName + " select " + InsertValue;
                        eSqlCommand.ExecuteNonQuery();
                        ResultString = "新信息添加成功！";
                    }
                    else
                    {
                        ResultString = "ID信息已经存在！";
                    }
                }//单个插入记录
                else
                {
                    eSqlCommand.CommandText = "insert into " + TableName + " select " + InsertValue;
                    eSqlCommand.ExecuteNonQuery();
                    ResultString = "新信息添加成功！";
                }
            }
            catch (Exception ex)
            {
                ResultString = ex.Message.ToString() + "     数据添加操作失败!";
            }
            eSqlConnection.Close();
            return ResultString;
        }
        public string Update(string TableName, string WhereString, string UpdateString, bool SingleUpdate)
        {
            string ResultString = null;
            eSqlConnection.Open();
            try
            {
                eSqlCommand.Connection = eSqlConnection;
                if (WhereString != "")
                {
                    eSqlCommand.CommandText = "update " + TableName + " set " + UpdateString + " where " + WhereString;
                }//单次更新
                else
                {
                    eSqlCommand.CommandText = "update " + TableName + " set " + UpdateString;
                }//批量更新
                eSqlCommand.ExecuteNonQuery();
                if (SingleUpdate)
                {
                    ResultString = "修改操作成功！";
                }
            }
            catch (Exception ex)
            {
                ResultString = ex.Message.ToString() + WhereString + "     数据库更新操作失败!";
            }
            eSqlConnection.Close();
            return ResultString;
        }
        public DataView Query(string TableName, string ProjectionString, string WhereString)
        {
            eSqlConnection.Open();
            if (WhereString == "")
            {
                eSqlString = "select " + ProjectionString + " from " + TableName;
            }
            else
            {
                eSqlString = "select " + ProjectionString + " from " + TableName + " where " + WhereString;
            }
            SqlDataAdapter eSqlDataAdapter = new SqlDataAdapter(eSqlString, eSqlConnection);
            eDataSet.Tables.Clear();
            eDataSet.Clear();
            eSqlDataAdapter.Fill(eDataSet, TableName);
            eSqlConnection.Close();
            eDataSet.Tables[TableName].DefaultView.AllowNew = false;
            return eDataSet.Tables[TableName].DefaultView;
        }
        public string Delete(string TableName, string DeleteString)
        {
            string ResultString = null;
            eSqlConnection.Open();
            try
            {
                eSqlCommand.Connection = eSqlConnection;
                eSqlCommand.CommandText = "delete  from " + TableName + " where " + DeleteString;
                eSqlCommand.ExecuteNonQuery();
                ResultString = "删除操作成功！";
            }
            catch (Exception ex)
            {

                ResultString = ex.Message.ToString() + "     数据库删除操作失败!";
            }
            eSqlConnection.Close();
            return ResultString;
        }

    }
}