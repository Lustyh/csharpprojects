﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Shopfloor_Servers
{
    class Program
    {
        static Servers servers = new Servers();
        static void Main(string[] args)
        {
            System.Console.Title = GetConfigValue.GetIP() + ":" + GetConfigValue.GetPort() + "   Version:" + GetLastWriteTime() + "_" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            Console.WriteLine("Version: " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString());
            Console.WriteLine("Start Init Config Class");
            GetConfigValue.ConfigInit();
            Console.WriteLine("Start Init RecordLog Class");
            OperationDatabaseClass.InitSWDatabass();
            Console.WriteLine("Start Init OperationDatabaseClass Class");
            RecordLog.Ini_RecordLog();
            Console.WriteLine("Start Init Shopfloor Class");
            Shopfloor.IniShopfloor();
            Console.WriteLine("Start Init Request Class");
            Requset.Ini_Request();
            Console.WriteLine("Start Init Check_OPID Class");
            Check_OPID.Init_CheckOPID();
            Console.WriteLine("Start Open HTTP Server");
            Servers.Open_servers();

            /*
            //servers.Open_servers();
            string  A = "{\"result\": \"FAIL\", \"message\": \"" + "SDHASJF" + ";$;" + "DSAFHKAJS" + "\"}";
            JObject jObject = JObject.Parse(A);
            Console.WriteLine(jObject.ToString());
            Console.WriteLine(System.Environment.CurrentDirectory);
            Console.WriteLine(RecordLog.GetLineNum());
            //Servers.Open_servers();
            Console.WriteLine(RecordLog.GetCurSourceFileName());
            //RecordLog.WriLogTxt("", "", "");
            
            Console.ReadKey();*/
        }
        private static string GetLastWriteTime()
        {
            System.Reflection.Assembly ma = System.Reflection.Assembly.GetEntryAssembly();
            FileInfo fi = new FileInfo(ma.Location);
            //FileVersionInfo mfv = FileVersionInfo.GetVersionInfo(ma.Location);
            //System.Reflection.Module mm = ma.ManifestModule;
            return fi.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}
