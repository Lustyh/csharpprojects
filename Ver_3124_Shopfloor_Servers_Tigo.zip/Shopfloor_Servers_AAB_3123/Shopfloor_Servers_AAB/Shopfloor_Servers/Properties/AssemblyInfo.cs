﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有关程序集的一般信息由以下
// 控制。更改这些特性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("Shopfloor_Servers")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Shopfloor_Servers")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 将 ComVisible 设置为 false 会使此程序集中的类型
//对 COM 组件不可见。如果需要从 COM 访问此程序集中的类型
//请将此类型的 ComVisible 特性设置为 true。
[assembly: ComVisible(false)]

// 如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
[assembly: Guid("cf308149-b896-40d5-b4fe-147daa6435dd")]

// 程序集的版本信息由下列四个值组成: [主版本，次版本，修订版本，生成号]
//
//      主版本: 表示整个程序的大版本号，当你对一个程序做了非常大的修改或升级，或者重构了整个程序时，应该将主版本号增加一位，代表一个重大的版本更新。
//      次版本: 表示整个程序的小版本号，当你对一个程序做了比较大的修改或添加了一些功能时，应该将次版本号增加一位，代表一个中等程度的版本更新。
//      修订号: 表示程序进行了一些修补或错误修复等小的修改，但并没有增加新功能，应该将修订版本号增加一位，代表一个修订版本更新。
//      生成号: 一般由编译器自动生成，用于标识编译版本。
//
// 可以指定所有值，也可以使用以下所示的 "*" 预置版本号和修订号
// 方法是按如下所示使用“*”: :
// 2.0.4.0 从2.0.1.4进阶到2.0.4.0  1.新增GET_DUT_TEST_INFO API， 2. SMT 3 times True fail  3.
// 2.0.4.1 upload os to SF (t6)
// 3.0.0.1 change AAB ABC test rule old(by project)  new(by station/Line)
// 3.0.0.2 fix true fail unit send errorcode to FPYCode of FATP
// 3.0.0.3 fix SMT can't record retest nft issue
// 3.0.0.4 fix SMT get dut info issue
// 3.0.1.0 add new data type GET_PRQ_CONFIG and add work_order and part_number in GET_DUT_TEST_INFO
// 3.0.1.1 SA-POGO one time true fail
// 3.0.1.2 add check station_id
// 3.0.1.2 add SA-RUNIN-CO one time fail
// 3.0.1.3 fix scof_pass record fail issue and add mars time check.
// 3.0.1.4 T6 DA add SAVE_FA_INFO to SF.
// 3.0.1.5 check invalid data in upload str and report fail.
// 3.0.1.6 check test fos flag at ALS-RGB station, if flag is Y, abort test and show FATP-FOS required.
// 3.0.1.7 check dut_sn rule, if it contains lower case and space, report error.
// 3.0.1.8 add check fos flag at FATP-CDT
// 3.0.1.9 add the funtion of parsing QA stations ErrorCode and uploading.(ACOS)
// 3.1.1.0 add BU10 projects SF logic
// 3.1.1.1 add BU10 projects FATP upload station parse logic.(project: YX6M, station: FWT2)
// 3.1.2.0 For the QA station use Mars/Clifford to upload Neptune logic update.(Use new QMS steps: LCOS/PCOS/OOBE)
// 3.1.2.1 add the logic of BU10 project SMT station upload variables' value same as FATP provision station's logic.
// 3.1.2.2 Support the device didn't first PASS and need to upload the value at SMT side.
// 3.1.2.3 Add EUT station for use Query_PQC with D4RPRO and D4R project
// 3.1.2.4 Add feature for Tigo project to support use DSN to query sf information
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("3.1.2.4")]
[assembly: AssemblyFileVersion("3.1.2.4")]
