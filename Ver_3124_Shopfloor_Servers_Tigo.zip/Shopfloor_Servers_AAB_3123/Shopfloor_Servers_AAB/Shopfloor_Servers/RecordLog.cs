﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace Shopfloor_Servers
{
    class RecordLog
    {
        private static string RequestLogPath, FailItemPath, FailFPYPath, ErrorPath, SF_Port;
        private static string split_str = "***********************************************************************";
        private static Random random = new Random();
        /// <summary>
        /// 取得当前源码的哪一行
        /// </summary>
        /// <returns></returns>
        private static int GetLineNum()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileLineNumber();
        }
        /// <summary>
        /// 取当前源码的源文件名
        /// </summary>
        /// <returns></returns>
        private static string GetCurSourceFileName()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileName();
        }

        /// <summary>
        /// Init recordLog class  get log path
        /// </summary>
        public static void Ini_RecordLog()
        {
            RequestLogPath = GetConfigValue.LogPath;
            FailItemPath = GetConfigValue.Fail_Item_Path;
            FailFPYPath = GetConfigValue.Fail_FPY_Path;
            ErrorPath = System.Environment.CurrentDirectory;
            SF_Port = GetConfigValue.GetPort();
        }

        /// <summary>
        /// get local time
        /// </summary>
        /// <param name="type"> split symbol </param>
        /// <returns> return now time </returns>
        private static string get_time(string type)
        {
            return DateTime.Now.ToString("yyyy") + type + DateTime.Now.ToString("MM") + type + DateTime.Now.ToString("dd");
        }

        /// <summary>
        /// Write all request/response/querydata/QDW/request/handshake log
        /// </summary>
        /// <param name="LogChar"> log </param>
        /// <param name="LogType"> log type </param>
        /// <param name="DUT_SN"> device SN </param>
        public static void WriLogTxt(string LogChar, string LogType, string DUT_SN)
        {
            try
            {
                string DateTime_log = get_time("\\"); //DateTime.Now.ToString("yyyy") + @"\" + DateTime.Now.ToString("MM") + @"\" + DateTime.Now.ToString("dd");
                if (!Directory.Exists(RequestLogPath + "\\" + DateTime_log))//如果不存在就创建file文件夹
                {
                    Directory.CreateDirectory(RequestLogPath + "\\" + DateTime_log);
                }
                StreamWriter WriteLog2Ser = new StreamWriter(RequestLogPath + "\\" + DateTime_log + "\\" + DUT_SN + ".log", true);
                WriteLog2Ser.AutoFlush = true;
                WriteLog2Ser.WriteLine(split_str);
                WriteLog2Ser.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff") + ": " + SF_Port); 
                WriteLog2Ser.WriteLine(LogType);
                WriteLog2Ser.WriteLine(LogChar);  
                WriteLog2Ser.WriteLine(split_str);  
                WriteLog2Ser.Flush(); 
                WriteLog2Ser.Close(); 
            }
            catch (Exception ee)
            {
                WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + ee.Message, "WriteSFLog");
                Console.WriteLine(GetCurSourceFileName() + ":" + GetLineNum() +"  " + ee.Message);
            }
        }
        /// <summary>
        /// Write all Error log
        /// </summary>
        /// <param name="LogChar"> log message </param>
        /// <param name="LogType"> log type </param>
        public static void WriLogError(string LogChar, string LogType)
        {
            try
            {
                string DateTime_log = get_time("\\"); //DateTime.Now.ToString("yyyy") + @"\" + DateTime.Now.ToString("MM") + @"\" + DateTime.Now.ToString("dd");
                if (!Directory.Exists(ErrorPath + "\\" + DateTime_log))//如果不存在就创建file文件夹
                {
                    Directory.CreateDirectory(ErrorPath + "\\" + DateTime_log);
                }
                StreamWriter WriteLog2Ser = new StreamWriter(ErrorPath + "\\" + DateTime_log + "\\" + get_time("_") + ".log", true);
                WriteLog2Ser.AutoFlush = true;
                WriteLog2Ser.WriteLine(split_str);
                WriteLog2Ser.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff") + ": ");
                WriteLog2Ser.WriteLine(LogType);
                WriteLog2Ser.WriteLine(LogChar);
                WriteLog2Ser.WriteLine(split_str);
                WriteLog2Ser.Flush();
                WriteLog2Ser.Close();
            }
            catch (Exception ee)
            {
                Console.WriteLine(GetCurSourceFileName() + ":" + GetLineNum() + "  " + ee.Message);
            }
        }
        /// <summary>
        /// Recode the FAIL Item when test fail
        /// </summary>
        /// <param name="DUT_SN"> device SN </param>
        /// <param name="STATION"> fail station id </param>
        /// <param name="line_id"> fail Line id </param>
        /// <param name="FIXTURE"> fail fixture id </param>
        /// <param name="Fail_Item"> fail items </param>
        /// <param name="Fail_Item_Value"> fail items and value </param>
        public static void WriFAILitem(string DUT_SN, string STATION, string line_id, string FIXTURE, string Fail_Item, string Fail_Item_Value)
        {
            try
            {
                string WriLogPath2Ser = FailItemPath + "\\" + STATION;
                string DateTime_log = get_time("_"); 
                if (!Directory.Exists(FailItemPath + "\\" + STATION))//如果不存在就创建file文件夹
                {
                    Directory.CreateDirectory(FailItemPath + "\\" + STATION);
                }

                StreamWriter WriteLog2Ser = new StreamWriter(WriLogPath2Ser + "\\" + DateTime_log + ".csv", true);
                WriteLog2Ser.AutoFlush = true;
                WriteLog2Ser.WriteLine(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ") + "," + line_id + "," + FIXTURE + "," + DUT_SN + ",\"" + Fail_Item + "\",\"" + Fail_Item_Value + "\"");
                WriteLog2Ser.Flush();
                WriteLog2Ser.Close();
            }
            catch (Exception wfi)
            {
                WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + wfi.Message, "WriteFAILItemLog");
                Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + wfi.Message);
            }
        }

        /// <summary>
        /// Recode the Fail FPY
        /// </summary>
        /// <param name="DUT_SN"> device SN </param>
        /// <param name="STATION"> station id </param>
        /// <param name="FIXTURE"> fixture id</param>
        /// <param name="STATUS"> FPY status (PASS/FAIL/RETEST/NTF/OFFLINE) </param>
        /// <param name="config"> device config </param>
        /// <param name="PN"> device PN </param>
        public static void WriFPY(string DUT_SN, string STATION, string FIXTURE, string STATUS, string config,string PN)
        {
            try
            {
                string DateTime_log = get_time("_");
                if (!Directory.Exists(FailFPYPath + "\\" + STATION))//如果不存在就创建file文件夹
                {
                    Directory.CreateDirectory(FailFPYPath + "\\" + STATION);
                }
                StreamWriter WriteLog2Ser = new StreamWriter(FailFPYPath + "\\" + STATION + "\\" + DateTime_log + ".csv", true);
                WriteLog2Ser.AutoFlush = true;
                WriteLog2Ser.WriteLine(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ") + "," + DUT_SN + "," + STATION + "," + FIXTURE + "," + STATUS + "," + config + "," + PN);
                WriteLog2Ser.Flush(); 
                WriteLog2Ser.Close(); 
            }
            catch (Exception wfpy)
            {
                WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + wfpy.Message, "WriteFPYLog");
                Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + wfpy.Message);
            }
        }
        /// <summary>
        /// Save FPY log to DB
        /// CREATE table FPYLog(Code32 varchar(36) PRIMARY KEY,
        ///             SN varchar(50) NOT NULL,
        ///             Station varchar(50),
        ///			    Fixture varchar(50),
        ///             Line varchar(50),
        ///             FPYCode varchar(20),
        ///             Config varchar(50),
        ///             PN varchar(50),
        ///             WO varchar(50),
        ///             SaveTime datetime)
        /// 
        /// </summary>
        /// <param name="Code32"> md5 value </param>
        /// <param name="SN"> serial number </param>
        /// <param name="Station"> station id </param>
        /// <param name="fixture_id"> fixture id </param>
        /// <param name="line"> line id </param>
        /// <param name="FPYCode"> Test result code </param>
        /// <param name="Config"> device config </param>
        /// <param name="PN"> Shopfloor PN </param>
        /// <param name="WO"> Shopfloor WO </param>
        /// <param name="SaveTime"> Save Time </param>
        public static void SaveFPYToDB(string Code32, string SN, string Station, string fixture_id, string line, string FPYCode, string Config, string PN, string WO, string SaveTime)
        {
            if (GetConfigValue.DBStatus != "TRUE") return;
            new Thread(new ThreadStart(() =>
            {
                try
                {
                    string strInsert = "\"('" + Code32 + "','" + SN + "','" + Station + "','" + fixture_id + "','" + line + "','" + FPYCode + "','" + Config + "','" + PN + "','" + WO + "','" + SaveTime + "')\"";
                    string upload_result = tRunCmd("./upload_data_SWDB.exe", string.Format("{0} {1} {2}", "FPYLog", "Code32='" + Code32 + "'", strInsert));
                    if (upload_result.Contains("Fail"))
                    {
                        Console.WriteLine(upload_result);
                    }
                }
                catch (Exception CallDB)
                {
                    WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message, "SaveFPYToDBLog");
                    Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message);
                }
            }
            )).Start();
        }
        /// <summary>
        /// Save fail log to DB
        /// CREATE table FailLog(Code32 varchar(36) PRIMARY KEY,
        ///                      SN varchar(50) NOT NULL,
        ///                      Station varchar(50),
	    ///				         Fixture varchar(50),
		///			             Line varchar(50),
		///			             FailMode varchar(6000),
		///			             FailDsp varchar(6000),
		///			             SaveTime datetime)
        /// </summary>
        /// <param name="Code32"> md5 value </param>
        /// <param name="SN"> serial number </param>
        /// <param name="Station"> station id </param>
        /// <param name="fixture_id"> fixture id </param>
        /// <param name="line"> line id </param>
        /// <param name="failmode"> fail items </param>
        /// <param name="faildsp"> fail items and value </param>
        /// <param name="SaveTime"> save time </param>
        public static void SaveFailLogToDB(string Code32, string SN, string Station, string fixture_id, string line, string failmode, string faildsp, string SaveTime)
        {
            if (GetConfigValue.DBStatus != "TRUE") return;
            new Thread(new ThreadStart(() =>
            {
                try
                {
                    string strInsert = "\"('" + Code32 + "','" + SN + "','" + Station + "','" + fixture_id + "','" + line + "','" + failmode + "','" + faildsp + "','" + SaveTime + "')\"";
                    string upload_result = tRunCmd("./upload_data_SWDB.exe", string.Format("{0} {1} {2}", "FailLog", "Code32='" + Code32 + "'", strInsert));
                    Console.WriteLine(upload_result);
                    if (upload_result.Contains("Fail"))
                    {
                        Console.WriteLine(upload_result);
                    }
                    //OperationDatabaseClass.Insert("SEL_SFC", "Code32='" + Code32 + "'", "('" + Code32 + "','" + SN + "','" + Station + "','" + fixture_id + "','" + DataType + "','" + strInput + "','" + InputTime + "','" + strOutput + "','" + OutputTime + "','" + Port + "')");
                }
                catch (Exception CallDB)
                {
                    WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message, "SaveFailLogToDBLog");
                    Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message);
                }
            }
            )).Start();
        }
        /// <summary>
        /// Save Clifford log to our DBserver
        /// CREATE table SEL_SFC(Code32 varchar(36) PRIMARY KEY,
        ///                      SN varchar(50) NOT NULL,
        ///                      Station varchar(50),
		///			             Fixture varchar(50),
		///			             DataType varchar(20),
		///			             strInput varchar(6000),
		///			             InputTime datetime,
        ///                      strOutput varchar(6000),
		///			             OutputTime datetime,
        ///                      Port varchar(10) NOT NULL)
        /// </summary>
        /// <param name="Code32">md5</param>
        /// <param name="SN"> serial number </param>
        /// <param name="Station"> Shopfloor station </param>
        /// <param name="fixture_id"> fixture id </param>
        /// <param name="DataType"> connect/connectfinal/SendRecvDataSFC </param>
        /// <param name="strInput"> input string </param>
        /// <param name="InputTime"> input time </param>
        /// <param name="strOutput"> output string </param>
        /// <param name="OutputTime"> output string </param>
        /// <param name="Port"> shopfloor port </param>
        public static void SavaCliffordToDB(string Code32, string SN, string Station, string fixture_id, string DataType, string strInput, string InputTime, string strOutput, string OutputTime, string Port)
        {
            if (GetConfigValue.DBStatus != "TRUE") return;
            new Thread(new ThreadStart(() =>
            {
                try
                {
                    if (strInput.Length>6000)
                    {
                        strInput = strInput.Substring(0, 6000);
                    }
                    string strInsert = "\"('" + Code32 + "','" + SN + "','" + Station + "','" + fixture_id + "','" + DataType + "','" + strInput + "','" + InputTime + "','" + strOutput + "','" + OutputTime + "','" + Port + "')\"";
                    string upload_result = tRunCmd("./upload_data_SWDB.exe", string.Format("{0} {1} {2}", "SEL_SFC", "Code32='" + Code32 + "'", strInsert));
                    if (upload_result.Contains("Fail"))
                    {
                        Console.WriteLine(upload_result);
                    }
                    //OperationDatabaseClass.Insert("SEL_SFC", "Code32='" + Code32 + "'", "('" + Code32 + "','" + SN + "','" + Station + "','" + fixture_id + "','" + DataType + "','" + strInput + "','" + InputTime + "','" + strOutput + "','" + OutputTime + "','" + Port + "')");
                }
                catch (Exception CallDB)
                {
                    WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message, "SavaCliffordToDBLog");
                    Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message);
                }
            })).Start();
            
        }
        /// <summary>
        /// Save shopfloor log to our DBserver
        /// CREATE table QueryDataLog(Code32 varchar(36) PRIMARY KEY,
        ///                           SN varchar(50) NOT NULL,
        ///                           Station varchar(50),
		///				              Step varchar(50),
		///				              strInput varchar(6000),
		///				              InputTime datetime,
        ///                           strOutput varchar(6000),
		///				              OutputTime datetime,
        ///                           ServerIP varchar(16))
        /// </summary>
        /// <param name="Code32"> MD5 </param>
        /// <param name="SN"> serial number </param>
        /// <param name="Station"> shopfloor station id </param>
        /// <param name="DataType"> querydata/request </param>
        /// <param name="Step"> shopfloor step </param>
        /// <param name="strInput"> input string </param>
        /// <param name="InputTime"> input time </param>
        /// <param name="strOutput"> output string </param>
        /// <param name="OutputTime"> Output time </param>
        /// <param name="ServerIP"> server IP </param>
        public static void SavaSFCToDB(string Code32, string SN, string Station, string DataType, string Step, string strInput, string InputTime, string strOutput, string OutputTime, string ServerIP)
        {
            if (GetConfigValue.DBStatus != "TRUE") return;
            new Thread(new ThreadStart(() =>
            {
                try
                {
                    if (strInput.Length > 6000)
                    {
                        strInput = strInput.Substring(0, 6000);
                    }
                    string strInsert = "\"('" + Code32 + "','" + SN + "','" + Station + "','" + Step + "','" + strInput + "','" + InputTime + "','" + strOutput + "','" + OutputTime + "','" + ServerIP + "')\"";
                    string upload_result = tRunCmd("./upload_data_SWDB.exe", string.Format("{0} {1} {2}", DataType, "\"Code32='" + Code32 + "'\"", strInsert));
                    if (upload_result.Contains("Fail"))
                    {
                        Console.WriteLine(upload_result);
                    }
                    //OperationDatabaseClass.Insert(DataType, "Code32='" + Code32 + "'", "('" + Code32 + "','" + SN + "','" + Station + "','" + Step + "','" + strInput + "','" + InputTime + "','" + strOutput + "','" + OutputTime + "','" + ServerIP + "')");
                }
                catch (Exception CallDB)
                {
                    WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message, "SavaSFCToDBLog");
                    Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + CallDB.Message);
                }
            })).Start();
        }
        /// <summary>
        /// produce MD5 number
        /// </summary>
        /// <param name="SN"> Serial number </param>
        /// <returns></returns>
        public static string CreateMD5(string SN)
        {
            try
            {
                string str = SN + DateTime.Now.ToString("yyyyMMddHHmmssfff") + CreateRandom();
                MD5 md5 = new MD5CryptoServiceProvider();
                byte[] chs = System.Text.Encoding.Default.GetBytes(str);

                //计算字符串字节数组的MD5哈希值
                byte[] md5chs = md5.ComputeHash(chs);
                md5.Clear();
                string strMd5 = "";

                for (int i = 0; i < md5chs.Length; ++i)
                {
                    strMd5 += md5chs[i].ToString("X").PadLeft(2, '0');
                }
                return strMd5;
            }
            catch (Exception CreateMD5Error)
            {
                WriLogError(GetCurSourceFileName() + ":" + GetLineNum() + "  " + CreateMD5Error.Message, "CreateMD5Error");
                Console.WriteLine("[" + GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum() + "  " + CreateMD5Error.Message);
                return DateTime.Now.ToString("yyyyMMddHHmmssfff") + CreateRandom();
            }
        }
        public static string NomalCreatMD5(string str)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] chs = System.Text.Encoding.Default.GetBytes(str);

            //计算字符串字节数组的MD5哈希值
            byte[] md5chs = md5.ComputeHash(chs);
            md5.Clear();
            string strMd5 = "";

            for (int i = 0; i < md5chs.Length; ++i)
            {
                strMd5 += md5chs[i].ToString("X").PadLeft(2, '0');
            }
            return strMd5;
        }
        /// <summary>
        /// produce random number (100-999)
        /// </summary>
        /// <returns></returns>
        public static string CreateRandom()
        {
            return random.Next(100, 999).ToString();
        }
        /// <summary>
        /// Get time for our DBserver
        /// </summary>
        /// <returns></returns>
        public static string GetTimeForDB()
        {
            return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
        }
        /// <summary>
        /// cmd run
        /// </summary>
        /// <param name="name"> program name </param>
        /// <param name="command"> command list </param>
        /// <returns></returns>
        public static string tRunCmd(string name, string command)//运行一个cmd命令
        {
            Process p = new Process();
            p.StartInfo.FileName = name;
            p.StartInfo.Arguments = command;    // 执行参数
            p.StartInfo.UseShellExecute = false;        // 关闭Shell的使用
            p.StartInfo.RedirectStandardInput = true;   // 重定向标准输入
            p.StartInfo.RedirectStandardOutput = true;  // 重定向标准输出
            p.StartInfo.RedirectStandardError = true;   // 重定向错误输出
            p.StartInfo.CreateNoWindow = true;          // 设置不显示窗口
            p.Start();   //启动
            //p.WaitForExit();
            //p.StandardInput.WriteLine(command);       // 也可以用这种方式输入要执行的命令
            //p.StandardInput.WriteLine("exit");        // 不过要记得加上Exit，要不然下一行执行的时候会出错
            return p.StandardOutput.ReadToEnd();        // 从输出流取得命令执行结果
        }
    }
}
