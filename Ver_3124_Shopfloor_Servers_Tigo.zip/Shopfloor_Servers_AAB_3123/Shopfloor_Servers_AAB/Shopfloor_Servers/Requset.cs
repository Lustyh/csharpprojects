﻿using Ini;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shopfloor_Servers
{
    class Requset
    {
        private static JObject TotalErrorCode = new JObject();
        private static JObject StationUpload = new JObject();
        private static string[] strQMS = { "OTPKEY", "DeviceSN", "BTMAC", "BSSID_MAC", "WLMAC", "PRO_QRCODE", "PWM_VALUE", "OS" ,"SAVE_FA_INFO"};
        private static string[] strCli = { "OTP_NAME", "DSN", "BTMAC", "BSSID_MAC", "WLMAC", "QRCODE", "PANDORA:PWM_VALUE", "PANDORA:OS" , "PANDORA:SAVE_FA_INFO" };
        /// <summary>
        /// Init request class Get ErrorCode 
        /// </summary>
        public static void Ini_Request()
        {
            Get_ErrorCode();
            SetSFCUpload();
        }

        /// <summary>
        /// UserLogin API will check User id is exist or not
        /// </summary>
        /// <param name="RequestStr"></param>
        /// <param name="strMD5"></param>
        /// <returns>result</returns>
        public static string UserLogin(string RequestStr, string strMD5)
        {
            try
            {
                JObject jObject = JObject.Parse(RequestStr);
                string user_id = GetKeyValue(jObject, "user_id").ToUpper();
                string password = GetKeyValue(jObject, "password");
                if (user_id.Length != 8 && user_id.Length != 11)
                {
                    return UserInfoResponse("FAIL", "User id format error, Please Input your Work ID again", "", user_id);
                    //return "{\"result\": \"FAIL\", \"message\": \"Please Input your Work ID again\", \"data\":{\"role\":\"\", \"mars_id\":\"\"}}";
                }
                if (user_id.Length == 11)
                {
                    string[] manage_user = Manage_User(user_id, password);
                    if (user_id.Substring(0, 2) == "QU")
                    {
                        return UserInfoResponse(manage_user[0], manage_user[1], "MANAGE", user_id.Substring(3), true);
                    }
                    return UserInfoResponse(manage_user[0], manage_user[1], "MANAGE", user_id.Substring(3));
                }
                string[] check_permission = Check_OPID.Check_User(user_id, password);
                if (check_permission[0] == "PASS")
                {
                    return UserInfoResponse(check_permission[0], "OK", check_permission[1], user_id);
                }
                else if (check_permission[0] == "FAIL1")
                {
                    return UserInfoResponse("FAIL", check_permission[1], "", user_id);
                }
                string res_check = Shopfloor.DBInfo_OPID(user_id, "QueryOPID", "OPID=" + user_id);
                if (res_check.Contains("SET SF_CFG_CHK=PASS"))
                {
                    return UserInfoResponse("PASS", "OK", "OPERATOR", user_id);
                }
                else
                {
                    return UserInfoResponse("FAIL", res_check, "OPERATOR", user_id); 
                }

            }
            catch (Exception error_userlogin)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_userlogin.Message, "error_connect");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_userlogin.Message);
                return "{\"result\": \"FAIL\", \"message\": \"" + RequestStr + " " + error_userlogin.Message + "\"}";
            }

        }
        /// <summary>
        /// Connect API Entrance: Check the shopfloor routing.
        /// </summary>
        /// <param name="RequestStr"> Clifford request str </param>
        /// <returns> Response str </returns>
        public static string Connect(string RequestStr, string strMD5)
        {
            try
            {
                JObject jObject = JObject.Parse(RequestStr);
                string dut_sn = GetKeyValue(jObject, "dut_id"); //jObject.GetValue("dut_id").ToString().ToUpper();
                string fixture_id = GetKeyValue(jObject, "station_id"); //jObject.GetValue("station_id").ToString();
                foreach (string cha in new string[] { " ", "\r", "\n", "\b" })
                {
                    if (dut_sn.Contains(cha))
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"dut_sn contains invalid char <" + cha + ">\"}";
                    }
                }
                if (!dut_sn.ToUpper().Contains(dut_sn))
                {
                    return "{\"result\": \"FAIL\", \"message\": \"" + dut_sn + " contains lower case\"}";
                }
                if (!CheckRequest(dut_sn, fixture_id))
                { return RetureError("request", RequestStr); }
                dut_sn = DUT_SN_init(dut_sn);
                string QMS_step = "querydata";
#if QMB
                QMS_step = "querydata";
#endif
                string station = AnalysisStation(fixture_id, jObject);
                string line = split_lineid(fixture_id);
                string SF_Info;
                if (dut_sn == GetConfigValue.FATP_dummy_sn || dut_sn == GetConfigValue.SMT_dummy_sn)
                { return DummyConnect(); }
                if (Check_Station(station))
                {
                    string InputStr = "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;FixNO=" + fixture_id;
                    SF_Info = Shopfloor.DBInfo_SMT(dut_sn, station, "request", InputStr, strMD5, station);
                    if (SF_Info.ToUpper().Contains("RESULT=PASS"))
                    {
                        //string SCOF = Shopfloor.Get_str("SET SCOF=", ";$;", SF_Info);
                        TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
                        //return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
                        return "{\"result\": \"PASS\", \"message\": {\"SCOF\": \"" + Shopfloor.Get_str("SET SCOF=", ";$;", SF_Info) + "\"},\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
                    }
                    return "{\"result\": \"FAIL\", \"message\": \"" + SF_Info + ";$;" + station + "\"}";
                }
                else if (Check_UploadQAStations(station))
                {
                    QMS_step = "QueryData_PQC";
                    string InputStr = $"SN={dut_sn};$;Line={line};$;Station={station};$;";
                    SF_Info = Shopfloor.DBInfo_FATP(dut_sn, "SWDL", QMS_step, InputStr, AnalysisFATPSFDB(dut_sn), strMD5, station);
                    if (SF_Info.Contains("SET SF_CFG_CHK=PASS"))
                    {
                        TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
                        return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
                    }
                    return "{\"result\": \"FAIL\", \"message\": \"" + SF_Info + ";$;" + station + "\"}";
                }
                else
                {
                    string InputStr = Get_InputStr(dut_sn, station, fixture_id);
                    SF_Info = Shopfloor.DBInfo_FATP(dut_sn, "SWDL", QMS_step, InputStr, AnalysisFATPSFDB(dut_sn), strMD5, station);
                    bool check_fos_flag_pass = !((station.Contains("FATP-ALS-RGB") || station.Contains("FATP-CDT")) && Shopfloor.Get_str("SET SAVE_FA_INFO=", ";$;", SF_Info).Contains("Y"));
                    if (SF_Info.Contains("SET SF_CFG_CHK=PASS") && SF_Info.Contains("SET SF_Routing_CHK=PASS") && check_fos_flag_pass)
                    {
                        return CheckTestRule_new(SF_Info, dut_sn, fixture_id);
                    }
                    if (!check_fos_flag_pass)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + ";FATP-FOS test required!!!!!!!!;$;" + station + "\"}";
                    }
                    return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + ";Routing Check Fail:suggest to:" + Shopfloor.Get_str("SET STATUS=", ";$;", SF_Info) + ";$;" + station + "\"}";
                }
            }
            catch (Exception error_connect)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_connect.Message, "error_connect");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_connect.Message);
                return "{\"result\": \"FAIL\", \"message\": \"" + RequestStr + " " + error_connect.Message + "\"}";
            }

        }

        /// <summary>
        /// SendRecvDataSFC API Entrance: Get shopfloor data
        ///         Include GET_SF_TIME_MILLIS/CHECK_SCOF/GET_ASSEMBLY_DATA/GET_DUT_DATA/GET_BUILD_PHASE/GET_DUT_CONFIG
        /// </summary>
        /// <param name="RequestStr"> Clifford request str </param>
        /// <returns> Response str </returns>
        public static string SendRecvDataSFC(string RequestStr, string strMD5)
        {
            try
            {
                JObject jObject = JObject.Parse(RequestStr);
                //string dut_sn = jObject.GetValue("dut_id").ToString().ToUpper();
                string data_type = GetKeyValue(jObject, "data_type");//jObject.GetValue("data_type").ToString().ToUpper();
                string QMS_step = "querydataBatch";
#if QMB
                QMS_step = "querydataBatch";
#endif
                if (data_type == "GET_DUT_CONFIG" || data_type == "GET_DUT_TEST_INFO")
                {
                    QMS_step = "querydata";
                }
                if (data_type == "GET_SF_TIME_MILLIS")
                {
                    TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
                    return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
                }
                string fixture_id = GetKeyValue(jObject, "station_id");//jObject.GetValue("station_id").ToString();
                string dut_sn = GetKeyValue(jObject, "dut_id"); //jObject.GetValue("dut_id").ToString().ToUpper();
                if (!CheckRequest(dut_sn, fixture_id))
                { return RetureError("request", RequestStr); }
                dut_sn = DUT_SN_init(dut_sn);
                string station = AnalysisStation(fixture_id, jObject);
                string project = AnalysisProject(fixture_id, jObject);
                string SF_Info = "";

                if (data_type == "GET_DUT_TEST_INFO" && (dut_sn.Substring(0, 3) == "BOE" && dut_sn.Length == 37))
                {
                    //{"result": "PASS", "message": "OK","data":{"device_config": "GA04751-US","build_phase": "MP","retest_policy": "AAB","scof": "OFF","cof": "OFF","work_order": "336054346", "part_number": ""}}
                    return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"device_config\": \"" + "" + "\",\"build_phase\": \"" + "MP" +
                                "\",\"retest_policy\": \"" + "" + "\",\"scof\": \"" + "OFF" + "\",\"cof\": \"" + "OFF" +
                                "\",\"work_order\": \"" + "" + "\", \"part_number\": \"" + "" + "\"}}";
                }
                if (data_type == "CHECK_SCOF")
                {
                    return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\": {\"SCOF\" : \"" + Check_SCOF(GetKeyValue(jObject, "project_id").ToUpper(), station) +
                        "\", \"scof\" : \"" + Check_SCOF(GetKeyValue(jObject, "project_id").ToUpper(), station) + "\"}}";
                }
                else if (data_type == "CHECK_COF")
                {
                    return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\": {\"cof\" : \"" + Check_COF(GetKeyValue(jObject, "project_id").ToUpper(), station) + "\"}}";
                }
                else if (data_type == "GET_RETEST_POLICY")
                {
                    return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\": {\"retest_policy\" : \"" + Check_RetestRule(GetKeyValue(jObject, "project_id").ToUpper()) + "\"}}";
                }
                if (Check_Station(station))
                {
                    if (!(dut_sn == GetConfigValue.BU10_dummy_sn))
                    {
                        SF_Info = Shopfloor.DBInfo_SMT(dut_sn, "MLBRouting", "request", "MB_NUM=" + dut_sn, strMD5, station);
                        if (!SF_Info.Contains("Config"))
                        {
                            return "{\"result\": \"FAIL\", \"message\": \"" + SF_Info + "\"}";
                        }
                    }
                }
                else
                {
                    if (!(dut_sn == GetConfigValue.BU10_dummy_sn))
                    {
                        string InputStr = Get_InputStr(dut_sn, station, fixture_id, data_type);
                        /*"SN=" + dut_sn + ";$;nextstation=" + station + ";$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;";
                        if (Check_SNtype(dut_sn))
                        {
                            InputStr = "MB_NUM=" + dut_sn + ";$;nextstation=" + station + ";$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;";
                        }*/
                        SF_Info = Shopfloor.DBInfo_FATP(dut_sn, "SWDL", QMS_step, InputStr, AnalysisFATPSFDB(dut_sn), strMD5, station);
                        if (!SF_Info.Contains("SET SF_CFG_CHK=PASS"))
                        {
                            return "{\"result\": \"FAIL\", \"message\": \"line 518 " + SF_Info + "\"}";
                        }
                    }
                }

                switch (data_type)
                {
                    // case "CHECK_SCOF":
                    //    return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\": {\"SCOF\" : \"" + Check_SCOF(GetKeyValue(jObject, "project_id").ToUpper(), station) + "\"}}";
                    case "GET_ASSEMBLY_DATA":
                        string key_word = GetConfigValue.GetAssembly(GetKeyValue(jObject, "project_id").ToUpper());
                        if (key_word == "")
                        {
                            key_word = "MLB_RAM,MLB_ROM,MB_NUM,PN_SPK,TOPLED,TOP_MIC,";
                        }
                        string assemstr = string.Empty;

                        foreach (string k_v in key_word.Split(','))
                        {
                            if (k_v.Trim().Length == 0) continue;
                            if (SF_Info.Contains(k_v.Trim()))
                            {
                                assemstr += "{\"module_part_type\":\"" + k_v.Trim() + "\",\"module_serial_number\":\"" + Shopfloor.Get_str(k_v + "=", ";$;", SF_Info) + "\",\"module_gpn\":\"\",\"module_mpn\":\"\",\"manufacture\":\"\",\"lot_code\":\"\"},";
                            }
                        }
                        return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"ASSEMBLY_DATA\": [" + assemstr.Remove(assemstr.Length - 1) + "]}}";
                    case "GET_DUT_ASSEMBLE":
                        string key_word2 = GetConfigValue.GetAssembly(GetKeyValue(jObject, "project_id").ToUpper());
                        if (key_word2 == "")
                        {
                            key_word2 = "MLB_RAM,MLB_ROM,MB_NUM,PN_SPK,TOPLED,TOP_MIC,";
                        }
                        string assemstr2 = string.Empty;

                        foreach (string k_v in key_word2.Split(','))
                        {
                            if (k_v.Trim().Length == 0) continue;
                            if (SF_Info.Contains(k_v.Trim()))
                            {
                                assemstr2 += "{\"module_part_type\":\"" + k_v.Trim() + "\",\"module_serial_number\":\"" + Shopfloor.Get_str(k_v + "=", ";$;", SF_Info) + "\",\"module_gpn\":\"\",\"module_mpn\":\"\",\"manufacture\":\"\",\"lot_code\":\"\"},";
                            }
                        }
                        return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"ASSEMBLY_DATA\": [" + assemstr2.Remove(assemstr2.Length - 1) + "]}}";
                    case "GET_DUT_SN":
                        {
                            if (!Check_Station(station) && Check_BU10project(project))
                            {
                                SF_Info = SF_Info.Replace('"', ' ');
                                SF_Info = "{" + Split_SF(SF_Info) + "}";
                                JObject SF_dct = JObject.Parse(SF_Info);
                                string ResultStr = "{ \"result\": \"PASS\", \"message\": \"OK\", \"data\":" + SF_dct + "}";
                                return ResultStr;
                            }
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"Work_Order\": \"" + "\", \"Station\": \"" + Shopfloor.Get_str("SET STATUS=", ";$;", SF_Info) +
                            "\", \"ErrorCode\": \"\", \"MBSN\": \"" + Shopfloor.Get_str("SET MB_NUM=", ";$;", SF_Info) + "\", \"MB_SKU\": \"" + Shopfloor.Get_str("SET MLB_CONFIG=", ";$;", SF_Info) +
                                    "\", \"SF_QCI_MBSN\": \"" + Shopfloor.Get_str("SET MB_NUM=", ";$;", SF_Info) + "\", \"BT/B_NUM\": \"\", \"BT/B_BTMAC\": \"\", \"QCI_Model\": \"" +
                                    "\", \"VGA\": \"\", \"SF_QCI_SN\": \"" + Shopfloor.Get_str("SET SN=", ";$;", SF_Info) + "\", \"SF_QCI_SF_QCI_SN\": \"" + Shopfloor.Get_str("SET SN=", ";$;", SF_Info) +
                                    "\", \"SEL_PN\": \"\", \"User_code\": \"\", \"Group_code\": \"" + "\", \"FCT_VER2\": \"" + Shopfloor.Get_str("SET FCT_RF_VER=", ";$;", SF_Info) + "\", " + Split_SF(SF_Info) +
                                    "\"Keyboard1\": \"\", \"MFG_PN1\": \"\", \"LTE1\": \"NA\", \"Touchscreen1\": \"\"}}";
                        }
                    case "GET_DUT_DATA":
                        if (Check_Station(station))
                        {
                            if (Check_BU10project(project))
                            {
                                if(dut_sn == GetConfigValue.BU10_dummy_sn)
                                {
                                    SF_Info = "SET WO=335763548;$;SET BTMAC=;$;SET WIFIMAC=;$;SET ModelDesc=YX6ESMB;$;SET BMac=;$;SET WMac=;$;SET EMac=;$;SET Wifi_2G=C09879A4753C;$;SET Wifi_5G=C09879A4753B;$;SET Wifi_6G=C09879A4753D;$;SET EMAC0=C09879A4753F;$;SET EMAC1=C09879A4753E;$;SET Config=MP;$;SET ACCE=;$;SET BIN=;$;SET BUILD=MP;$;SET Station=CAOI01;$;SET Line=E34;$;SET Imageversion=YX6ES_1.20.302414.F;$;SET Hwid=0100;$;SET EmmcName=004GA1;SM0000;$;SET PJ_ID=00;$;SET CPUType=;$;SET MLB_Repair=N;$;SET MBSN=B2CYX6EM28K000K1;$;";
                                }
                                SF_Info = "{" + Split_SF(SF_Info) + "}";
                                JObject SF_dct = JObject.Parse(SF_Info);
                                string ResultStr = "{ \"result\": \"PASS\", \"message\": \"OK\", \"data\":" + SF_dct + "}";
                                return ResultStr;
                            }
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"Work_Order\": \"" + "\", \"Station\": \"" + Shopfloor.Get_str("SET Station=", ";$;", SF_Info) +
                            "\", \"ErrorCode\": \"\", \"MBSN\": \"" + dut_sn + "\", \"MB_SKU\": \"" + Shopfloor.Get_str("SET Config=", ";$;", SF_Info) +
                                    "\", \"SF_QCI_MBSN\": \"" + dut_sn + "\", \"BT/B_NUM\": \"\", \"BT/B_BTMAC\": \"\", \"QCI_Model\": \"" +
                                    "\", \"VGA\": \"\", \"SF_QCI_SN\": \"" + Shopfloor.Get_str("SET SN=", ";$;", SF_Info) + "\", \"SF_QCI_SF_QCI_SN\": \"" + Shopfloor.Get_str("SET SN=", ";$;", SF_Info) +
                                    "\", \"SEL_PN\": \"\", \"User_code\": \"\", \"Group_code\": \"" + "\", \"FCT_VER2\": \"" + Shopfloor.Get_str("SET FCT_RF_VER=", ";$;", SF_Info) + "\", " + Split_SF(SF_Info) +
                                    "\"Keyboard1\": \"\", \"MFG_PN1\": \"\", \"LTE1\": \"NA\", \"Touchscreen1\": \"\"}}";
                        }
                        else
                        {
                            if (Check_BU10project(project))
                            {
                                if (dut_sn == GetConfigValue.BU10_dummy_sn)
                                {
                                    SF_Info = "SET WO=335763548;$;SET BTMAC=;$;SET WIFIMAC=;$;SET ModelDesc=YX6ESMB;$;SET BMac=;$;SET WMac=;$;SET EMac=;$;SET Wifi_2G=C09879A4753C;$;SET Wifi_5G=C09879A4753B;$;SET Wifi_6G=C09879A4753D;$;SET EMAC0=C09879A4753F;$;SET EMAC1=C09879A4753E;$;SET Config=MP;$;SET ACCE=;$;SET BIN=;$;SET BUILD=MP;$;SET Station=CAOI01;$;SET Line=E34;$;SET Imageversion=YX6ES_1.20.302414.F;$;SET Hwid=0100;$;SET EmmcName=004GA1;SM0000;$;SET PJ_ID=00;$;SET CPUType=;$;SET MLB_Repair=N;$;SET MTP_Ver=;$;SET CSN=54321;$;SET FCT_VER=YX6ES_1.20.302414.F;$;SET MCU_Version=EU;$;SET System_Version=1e5dab02c23be1dd413b9a61cc1b6fd0;$;SET ShippingImg=0406_421_MFG;$;SET SSID2G=PredatorW6 - TEST - 2.4GHz;$;SET SSID5G=PredatorW6 - TEST - 5GHz;$;SET SSID6G=PredatorW6 - TEST - 6GHz;$;SET AdminPWD=AcerTEST;$;SET SSIDPWD=ConnectTEST;$;SET MBSN=B2CYX6EM28K000K1;$;";
                                }
                                SF_Info = SF_Info.Replace('"',' ');
                                SF_Info = "{" + Split_SF(SF_Info) + "}";
                                JObject SF_dct = JObject.Parse(SF_Info);
                                string ResultStr = "{ \"result\": \"PASS\", \"message\": \"OK\", \"data\":" + SF_dct + "}";
                                return ResultStr;
                            }
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"Work_Order\": \"" + "\", \"Station\": \"" + Shopfloor.Get_str("SET STATUS=", ";$;", SF_Info) +
                            "\", \"ErrorCode\": \"\", \"MBSN\": \"" + Shopfloor.Get_str("SET MB_NUM=", ";$;", SF_Info) + "\", \"MB_SKU\": \"" + Shopfloor.Get_str("SET MLB_CONFIG=", ";$;", SF_Info) +
                                    "\", \"SF_QCI_MBSN\": \"" + Shopfloor.Get_str("SET MB_NUM=", ";$;", SF_Info) + "\", \"BT/B_NUM\": \"\", \"BT/B_BTMAC\": \"\", \"QCI_Model\": \"" +
                                    "\", \"VGA\": \"\", \"SF_QCI_SN\": \"" + Shopfloor.Get_str("SET SN=", ";$;", SF_Info) + "\", \"SF_QCI_SF_QCI_SN\": \"" + Shopfloor.Get_str("SET SN=", ";$;", SF_Info) +
                                    "\", \"SEL_PN\": \"\", \"User_code\": \"\", \"Group_code\": \"" + "\", \"FCT_VER2\": \"" + Shopfloor.Get_str("SET FCT_RF_VER=", ";$;", SF_Info) + "\", " + Split_SF(SF_Info) +
                                    "\"Keyboard1\": \"\", \"MFG_PN1\": \"\", \"LTE1\": \"NA\", \"Touchscreen1\": \"\"}}";
                        }
                    case "GET_BUILD_PHASE":
                        return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"BUILD\": \"" + Shopfloor.Get_str("SET BUILD=", ";$;", SF_Info) + "\", \"build_phase\": \"" + Shopfloor.Get_str("SET BUILD=", ";$;", SF_Info) + "\"}}";
                    case "GET_PRQ_CONFIG":
                        return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"work_order\": \"" + Shopfloor.Get_str("SET WO=", ";$;", SF_Info) + "\", \"part_number\": \"" + Shopfloor.Get_str("SET GPN=", ";$;", SF_Info) + "\"}}";
                    case "GET_DUT_CONFIG":
                        if (Check_Station(station))
                        {
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"SKU\": \"" + Shopfloor.Get_str("SET Config=", ";$;", SF_Info) + "\", \"device_config\": \"" + Shopfloor.Get_str("SET Config=", ";$;", SF_Info) + "\"}}";
                        }
                        else
                        {
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"SKU\": \"" + Shopfloor.Get_str("SET SKU=", ";$;", SF_Info) + "\", \"device_config\": \"" + Shopfloor.Get_str("SET SKU=", ";$;", SF_Info) + "\"}}";
                        }
                    case "GET_DUT_TEST_INFO":
                        if (Check_Station(station))
                        {
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"device_config\": \"" + Shopfloor.Get_str("SET SKU=", ";$;", SF_Info) + "\",\"build_phase\": \"" + Shopfloor.Get_str("SET BUILD=", ";$;", SF_Info) +
                                "\",\"retest_policy\": \"" + Check_RetestRule(GetKeyValue(jObject, "project_id").ToUpper()) + "\",\"scof\": \"" + Check_SCOF(GetKeyValue(jObject, "project_id").ToUpper(), station) + "\",\"cof\": \"" + Check_COF(GetKeyValue(jObject, "project_id").ToUpper(), station) +
                                "\",\"work_order\": \"" + Shopfloor.Get_str("SET WO=", ";$;", SF_Info) + "\", \"part_number\": \"" + Shopfloor.Get_str("SET GPN=", ";$;", SF_Info) + "\"}}";
                        }
                        else
                        {
                            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\":{\"device_config\": \"" + Shopfloor.Get_str("SET Config=", ";$;", SF_Info) + "\",\"build_phase\": \"" + Shopfloor.Get_str("SET BUILD=", ";$;", SF_Info) +
                                "\",\"retest_policy\": \"" + Check_RetestRule(GetKeyValue(jObject, "project_id").ToUpper()) + "\",\"scof\": \"" + Check_SCOF(GetKeyValue(jObject, "project_id").ToUpper(), station) + "\",\"cof\": \"" + Check_COF(GetKeyValue(jObject, "project_id").ToUpper(), station) +
                                "\",\"work_order\": \"" + Shopfloor.Get_str("SET WO=", ";$;", SF_Info) + "\", \"part_number\": \"" + Shopfloor.Get_str("SET GPN=", ";$;", SF_Info) + "\"}}";
                        }
                    default:
                        return "{\"result\": \"FAIL\", \"message\": \"" + "The Data type is not exist, Please check it! SN = " + dut_sn + "\"}";
                }
            }
            catch (Exception error_sendrecvdataSFC)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "] " + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_sendrecvdataSFC.Message, "error_sendrecvdataSFC");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "] " + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_sendrecvdataSFC.Message);
                return "{\"result\": \"FAIL\", \"message\": \"" + RequestStr + " " + error_sendrecvdataSFC.Message + "\"}";
            }
        }

        /// <summary>
        /// ConnectFinal API Entrance: Send test result to shopfloor and upload test data to shopfloor
        /// </summary>
        /// <param name="RequestStr"> Clifford Request str </param>
        /// <returns> Response str </returns>
        public static string ConnectFinal(string RequestStr, string strMD5)
        {
            try
            {
                JObject jObject = JObject.Parse(RequestStr);
                string dut_sn = GetKeyValue(jObject, "dut_id"); //jObject.GetValue("dut_id").ToString();
                string fixname = GetKeyValue(jObject, "station_id");  //jObject.GetValue("station_id").ToString();
                string status = GetKeyValue(jObject, "status"); //jObject.GetValue("status").ToString().ToUpper();
                string station = AnalysisStation(fixname, jObject);
                string project = AnalysisProject(fixname, jObject);
                dut_sn = DUT_SN_init(dut_sn);

                string QMS_step = "querydataBatch";
#if QMB
                QMS_step = "querydataBatch";
#endif
                /*
                if (dut_sn == GetConfigValue.FATP_dummy_sn)
                { return DummyConnectFinal(); }*/
                string Query_Info = "";
                string DB_Info = "";
                string[] ErrorCode = { "PASS;", "" };
                if (!Check_QAStations(station,project) || !Check_UploadQAStations(station))
                {
                    if ((status != "PASS" && status != "SCOF_PASS") && RequestStr.Contains("description"))
                    {
                        if (Check_BU10project(project))
                        {
                            if(GetKeyValue(jObject, "status") == "FAIL")
                            {
                                ErrorCode = FindBU10ErrorCode(dut_sn, station, fixname, GetKeyValue(jObject, "description"));
                                if (dut_sn != GetConfigValue.BU10_dummy_sn)
                                    AnalyseFailItem(strMD5, dut_sn, station, fixname, GetKeyValue(jObject, "description"));
                            }
                        }
                        else
                        {
                            ErrorCode = FindErrorCode(dut_sn, station, fixname, GetKeyValue(jObject, "description"));
                            AnalyseFailItem(strMD5, dut_sn, station, fixname, GetKeyValue(jObject, "description"));
                        }
                    }
                }
                string next_station = "", final_run = "False";
                if (Check_Station(station))
                {
                    //string QueryData = Shopfloor.DBInfo_SMT(dut_sn, "MLBRouting", "request", "MB_NUM=" + dut_sn, strMD5, station);
                    //RecordLog.SaveFPYToDB(strMD5, dut_sn, station, fixname, split_lineid(fixname), status, Shopfloor.Get_str("SET Config=", ";$;", QueryData), Shopfloor.Get_str("SET PN=", ";$;", QueryData), Shopfloor.Get_str("SET WO=", ";$;", QueryData), RecordLog.GetTimeForDB());
                    if (dut_sn != GetConfigValue.BU10_dummy_sn)
                    {
                        Query_Info = Shopfloor.DBInfo_SMT(dut_sn, station, "request", "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;FixNO=" + fixname, strMD5, station);
                        //string[] Status_Fcode = Check_Status(status, Shopfloor.Get_str("SET FailCount=", ";$;", Query_Info), ErrorCode[0]);
                        string[] Status_Fcode = SMT_Check_Status(status, Shopfloor.Get_str("SET FailCount=", ";$;", Query_Info), ErrorCode[0], project);
                        status = Status_Fcode[0];
                        if (status != "FAIL")
                        {
                            if (Check_BU10project(project) && Check_BU10uploadStation(station))
                            {
                                if (jObject.GetValue("description").ToString().ToUpper() != "OK" && (status == "PASS" || status == "SCOF_PASS" || status == "RETEST" || status == "NTF"))
                                {
                                    //Console.WriteLine("Use normal SN to debug SMT station's upload logic");
                                    JObject SF_Collect = (JObject)jObject.GetValue("description");
                                    string upload_str = "";
                                    string ff = "";
                                    upload_str = strBU10UploadSFC(SF_Collect, project, station);
                                    if (upload_str.Contains("") || upload_str == "")
                                    {
                                        return "{\"result\": \"FAIL\", \"message\": \"Invalid value in upload string\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                                    }
                                    if (upload_str != "SKIP")
                                    {
                                        ff = "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;RESULT=" + status + ";$;OPID=" + fixname + ";$;FixNO=" + fixname + ";$;ERRORCODE=" + ErrorCode[0].Substring(0, 5) + ";$;TOTALERRORCODE=" + ErrorCode[0] + upload_str + ";$;";
                                    }
                                    else
                                    {
                                        ff = "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;RESULT=" + status + ";$;OPID=" + fixname + ";$;FixNO=" + fixname + ";$;ERRORCODE=" + "PASS" + ";$;TOTALERRORCODE=" + "PASS;";
                                    }
                                    DB_Info = Shopfloor.DBInfo_SMT(dut_sn, station, "handshake", ff, strMD5, station);
                                }
                            }
                            else
                            {
                                DB_Info = Shopfloor.DBInfo_SMT(dut_sn, station, "handshake", "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;RESULT=" + status + ";$;OPID=" + fixname + ";$;FixNO=" + fixname + ";$;ERRORCODE=" + ErrorCode[0].Substring(0, 5) + ";$;TOTALERRORCODE=" + ErrorCode[0], strMD5, station);
                            }
                            next_station = Shopfloor.Get_str("SET NextStation=", ";$;", DB_Info);
                            if (status == "TBD") { final_run = "False"; }
                            else { final_run = "True"; }
                            if (dut_sn == GetConfigValue.SMT_dummy_sn)
                            {
                                return DummyConnectFinal();
                            }
                            if (DB_Info.ToUpper().Contains("RESULT=PASS") || DB_Info.ToUpper().Contains("RESULT=TBD"))
                            {
                                /*if (Status_Fcode[1] != "PASS" && Status_Fcode[1] != "TBD" && Status_Fcode[1] != "")
                                {
                                    RecordLog.WriFPY(dut_sn, station, fixname, status, Shopfloor.Get_str("SET Config=", ";$;", DB_Info), Shopfloor.Get_str("SET PN=", ";$;", DB_Info));
                                }*/
                                if (status != "PASS" && status != "TBD" && status != "")
                                {
                                    RecordLog.WriFPY(dut_sn, station, fixname, status, Shopfloor.Get_str("SET Config=", ";$;", DB_Info), Shopfloor.Get_str("SET PN=", ";$;", DB_Info));
                                }
                                return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"" + final_run + "\"}}";
                            }
                            else
                            {
                                return "{\"result\": \"FAIL\", \"message\": \"" + DB_Info + ":$;" + station + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"" + final_run + "\"}}";
                            }
                        }
                    }
                    else
                    {
                        if (Check_BU10project(project) && Check_BU10uploadStation(station))
                        {
                            if (jObject.GetValue("description").ToString().ToUpper() != "OK" && (status == "PASS" || status == "SCOF_PASS"))
                            {
                                //Console.WriteLine("Use dummy SN to debug SMT station's upload logic");
                                JObject SF_Collect = (JObject)jObject.GetValue("description");
                                string upload_str = "";
                                upload_str = strBU10UploadSFC(SF_Collect, project, station);
                                if (upload_str.Contains("") || upload_str == "")
                                {
                                    return "{\"result\": \"FAIL\", \"message\": \"Invalid value in upload string\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                                }
                                if (upload_str != "SKIP")
                                {
                                    string ff = "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;RESULT=" + status + ";$;OPID=" + fixname + ";$;FixNO=" + fixname + ";$;ERRORCODE=" + ErrorCode[0].Substring(0, 5) + ";$;TOTALERRORCODE=" + ErrorCode[0] + upload_str+ ";$;";
                                }
                                else
                                {
                                    string ff = "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;RESULT=" + status + ";$;OPID=" + fixname + ";$;FixNO=" + fixname + ";$;ERRORCODE=" + "PASS" + ";$;TOTALERRORCODE=" + "PASS;";
                                }
                                return DummyConnectFinal();
                            }
                        }
                    }
                    // status == fail
                    if (Requset.Check_project(fixname.Substring(0, fixname.IndexOf("_"))))
                    {
                        if (dut_sn == GetConfigValue.BU10_dummy_sn)
                        {
                            Console.WriteLine("Using dummy SN！");
                            DB_Info = "RESULT=PASS";
                        }
                        //当站打不良
                        else
                        {
                            DB_Info = Shopfloor.DBInfo_SMT(dut_sn, station, "handshake", "MB_NUM=" + dut_sn + ";$;Station=" + station + ";$;RESULT=" + status + ";$;OPID=" + fixname + ";$;FixNO=" + fixname + ";$;ERRORCODE=" + ErrorCode[0] + ";$;TOTALERRORCODE=" + ErrorCode[0], strMD5, station);
                            RecordLog.WriFPY(dut_sn, station, fixname, status, Shopfloor.Get_str("SET Config=", ";$;", DB_Info), Shopfloor.Get_str("SET PN=", ";$;", DB_Info));
                        }
                        if (dut_sn == GetConfigValue.SMT_dummy_sn)
                            return Requset.DummyConnectFinal();
                        
                        return DB_Info.ToUpper().Contains("RESULT=PASS") ? "{\"result\": \"PASS\", \"message\": \"OK\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"" + final_run + "\"}}" : "{\"result\": \"FAIL\", \"message\": \"" + DB_Info + ":$;" + station + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + Requset.getTime() + "\", \"final_run\": \"" + final_run + "\"}}";
                    }
                    return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"" + final_run + "\"}}";
                }
                else if (Check_UploadQAStations(station))
                {
                    QMS_step = "QDW_PQC";
                    bool UploadFormInfo = false;
                    string DB_Info_CheckForm = "";
                    string[] upload_str = { "","" };
                    string[] QAErrorCode = { "","","" };
                    string QMS_step_CheckForm = "CheckForm_PQC";
                    if (status != "PASS" && status != "SCOF_PASS")
                        QAErrorCode = GetPandoraErrorCode(JObject.Parse(GetKeyValue(jObject, "description"))); // { "ErrorCode", "", "FAIL" }
                        if (QAErrorCode[0].Contains(";*;UID=;*;") || QAErrorCode[0] == "ErrorCode")
                            return "{\"result\": \"FAIL\", \"message\": \"Invalid UID value in upload string\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    else if(status == "PASS" || status == "SCOF_PASS")
                        upload_str = strQAUploadSFC(JObject.Parse(GetKeyValue(jObject, "description"))); // { UID , FormInfo }
                        if (upload_str[0].Contains(";*;UID=;*;") || upload_str[0] == "")
                            return "{\"result\": \"FAIL\", \"message\": \"Invalid UID value in upload string\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    if(jObject.GetValue("description").ToString().ToUpper() != "OK" && (status == "PASS" || status == "SCOF_PASS"))
                    {
                        if (upload_str[1] == "") UploadFormInfo = true;
                        else
                        {
                            //string InputStr_CheckForm = "MASTER:SN=" + dut_sn + ";*;MASTER:STATION=" + station + upload_str[1] + ";*;MASTER:ERRORCODE=" + QAErrorCode[1] + ";*;MASTER:TOTALERRORCODE=" + QAErrorCode[1] + ";*;MASTER:FPYCODE=" + QAErrorCode[2] + upload_str[0];
                            string InputStr_CheckForm = "MASTER:SN=" + dut_sn + ";*;MASTER:STATION=" + station + upload_str[1] + ";*;MASTER:ERRORCODE=" + "PASS" + ";*;MASTER:TOTALERRORCODE=" + "PASS" + ";*;MASTER:FPYCODE=" + "PASS" + upload_str[0];
                            DB_Info_CheckForm = Shopfloor.DBInfo_FATP(dut_sn, "SWDL", QMS_step_CheckForm, InputStr_CheckForm, AnalysisFATPSFDB(dut_sn), strMD5, station);
                            if (DB_Info_CheckForm.Contains("SET SF_CFG_CHK=PASS"))
                            {
                                UploadFormInfo = true;
                            }
                        }
                        if(!(dut_sn == GetConfigValue.FATP_dummy_sn))
                            if (!UploadFormInfo) return "{\"result\": \"FAIL\", \"message\": \"" + DB_Info_CheckForm + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    }
                    string InputStr = "";
                    if (status == "PASS" || status == "SCOF_PASS")
                    {
                        // else if(jObject.GetValue("description").ToString().ToUpper() == "OK")
                        // MASTER:SN=WIP2B25105H800EVH;*;MASTER:STATION=LCOS;*;MASTER:ERRORCODE=PASS;*;MASTER:TOTALERRORCODE=PASS;*;MASTER:FPYCODE=PASS;*;UID=A123C789;*;
                        InputStr = "MASTER:SN=" + dut_sn + ";*;MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + "PASS" + ";*;MASTER:TOTALERRORCODE=" + "PASS" + ";*;MASTER:FPYCODE=" + "PASS" + upload_str[0];
                    }
                    else
                    {
                        InputStr = "MASTER:SN=" + dut_sn + ";*;MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + QAErrorCode[1] + ";*;MASTER:TOTALERRORCODE=" + QAErrorCode[1] + ";*;MASTER:FPYCODE=" + QAErrorCode[2] + QAErrorCode[0];
                    }
                    if (dut_sn == GetConfigValue.FATP_dummy_sn)
                    { return DummyConnectFinal(); }
                    if (QAErrorCode[1].Length != 5 && status == "FAIL")
                        return "{\"result\": \"FAIL\", \"message\": \"" + "Please check your errorcode value's format!" + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    DB_Info = Shopfloor.DBInfo_FATP(dut_sn, "SWDL", QMS_step, InputStr, AnalysisFATPSFDB(dut_sn), strMD5, station);
                    if (DB_Info.Contains("SET SF_CFG_CHK=PASS"))
                    {
                        return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\":{\"next_action\":\"" + Shopfloor.Get_str("SET NextSation=", ";$;", Query_Info) + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"" + final_run + "\"}}";
                    }
                    else
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + DB_Info + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    }
                }
                else
                {
                    if (dut_sn == GetConfigValue.BU10_dummy_sn)
                    {
                        if (Check_uploadStation(station))
                        {
                            if (jObject.GetValue("description").ToString().ToUpper() != "OK" && (status == "PASS" || status == "SCOF_PASS"))
                            {
                                JObject SF_Collect = (JObject)jObject.GetValue("description");
                                string upload_str = "";
                                if (Check_BU10project(project))
                                {
                                    upload_str = strBU10UploadSFC(SF_Collect,project,station);
                                }
                                else
                                {
                                    upload_str = strUploadSFC(SF_Collect);
                                }
                                if (upload_str.Contains("") || upload_str == "")
                                {
                                    return "{\"result\": \"FAIL\", \"message\": \"Invalid value in upload string\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                                }
                                if (upload_str != "SKIP")
                                {
                                    string ff = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + "PASS" + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + "" +
                                    upload_str + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                                    Console.WriteLine("connectfinal line 550 [ff]: {0}", ff);
                                }
                                else
                                {
                                    string ff = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + "PASS" + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + "PASS" + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                                    Console.WriteLine("connectfinal line 550 [ff]: {0}", ff);
                                }
                            }
                        }
                        return DummyConnectFinal();
                    }
                    string InputStr = Get_InputStr(dut_sn, station, fixname);
                    /*"SN=" + dut_sn + ";$;nextstation=" + station + ";$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;";
                    if (Check_SNtype(dut_sn))
                    {
                        InputStr = "MB_NUM=" + dut_sn + ";$;nextstation=" + station + ";$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;";
                    }*/
                    Query_Info = Shopfloor.DBInfo_FATP(dut_sn, "SWDL", QMS_step, InputStr, AnalysisFATPSFDB(dut_sn), strMD5, station);
                    if (!Query_Info.Contains("SF_CFG_CHK=PASS"))
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + DB_Info + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    }
                    RecordLog.SaveFPYToDB(strMD5, dut_sn, station, fixname, split_lineid(fixname), status, Shopfloor.Get_str("SET Config=", ";$;", Query_Info), Shopfloor.Get_str("SET PN=", ";$;", Query_Info), Shopfloor.Get_str("SET WO=", ";$;", Query_Info), RecordLog.GetTimeForDB());
                    string[] Status_Fcode = Check_Status(status, Shopfloor.Get_str("SET FailCount=", ";$;", Query_Info), ErrorCode[0], project);
                    InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + Status_Fcode[0] + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + Status_Fcode[1] + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                    if (Check_uploadStation(station))
                    {
                        if (jObject.GetValue("description").ToString().ToUpper() != "OK" && (status == "PASS" || status == "SCOF_PASS"))
                        {
                            JObject SF_Collect = (JObject)jObject.GetValue("description");
                            //Console.WriteLine("upload data to SFC: " + RequestStr);
                            //string upload_str = strUploadSFC(SF_Collect);
                            string upload_str = "";
                            if(Check_BU10project(project))
                            {
                                upload_str = strBU10UploadSFC(SF_Collect,project,station);
                            }
                            else
                            {
                                upload_str = strUploadSFC(SF_Collect);
                            }
                            //$W:3886F79A102A$H:16E.ynb$C:PLJ9FPSG$
                            if (upload_str.Contains("") || upload_str == "")
                            {
                                return "{\"result\": \"FAIL\", \"message\": \"Invalid value in upload string\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                            }
                            if (upload_str != "SKIP")
                            {
                                InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + Status_Fcode[0] + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + Status_Fcode[1] +
                                upload_str + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                            }
                            else
                            {
                                InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + Status_Fcode[0] + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + Status_Fcode[1] + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                            }
                        }
                        //";*;MASTER:OTPKEY=" + GetKeyValue(SF_Collect, "OTP_NAME") + ";*;MASTER:DeviceSN=" + GetKeyValue(SF_Collect, "DSN") + ";*;MASTER:BTMAC=" + GetKeyValue(SF_Collect, "BTMAC") + ";*;MASTER:BSSID_MAC=" + GetKeyValue(SF_Collect, "BSSID_MAC") +
                        //";*;MASTER:WLMAC=" + GetKeyValue(SF_Collect, "WLMAC") + ";*;MASTER:PRO_QRCODE=" + GetKeyValue(SF_Collect, "QRCODE") + ";*;MASTER:PWM_VALUE=" + GetPWM(SF_Collect, station) + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                    }
                    else if (Check_QAStations(station,project))
                    {
                        bool QAstation = jObject.GetValue("description").ToString().ToUpper() != "OK";
                        if (QAstation)
                        {
                            JObject SF_Collect = (JObject)jObject.GetValue("description");
                            string[] QAErrorCode = GetQAErrorCode(SF_Collect); // { "ErrorCode", "", "FAIL" }
                            if (QAErrorCode[1].Length != 5 && status == "FAIL")
                                return "{\"result\": \"FAIL\", \"message\": \"" + "Please check your errorcode value's format!" + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                            InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + QAErrorCode[1] + ";*;MASTER:TOTALERRORCODE=" + QAErrorCode[1] + ";*;MASTER:FPYCODE=" + QAErrorCode[2] + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + QAErrorCode[0] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                        }
                        else if(jObject.GetValue("description").ToString().ToUpper() == "OK")
                        {
                            InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + "PASS" + ";*;MASTER:TOTALERRORCODE=" + "PASS" + ";*;MASTER:FPYCODE=" + "PASS" + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + "" + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                        }
                    }
                    else if (Check_SNtype(dut_sn))
                    {
                        InputStr = "MASTER:MB_NUM=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + Status_Fcode[0] + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + Status_Fcode[1] + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                    }
                    else if (Check_hash_diff(jObject, station))
                    {
                        InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + "CFFF6" + ";*;MASTER:TOTALERRORCODE=" + "CFFF6;" + "*;MASTER:FPYCODE=" + "FAIL" + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                    }

                    if ((station == "SA-POGO" || station == "SA-RUNIN-CO") && (status !="PASS" && status != "SCOF_PASS"))
                    {
                        InputStr = "MASTER:SN=" + dut_sn + ";*;" + "MASTER:STATION=" + station + ";*;MASTER:ERRORCODE=" + "FAIL" + ";*;MASTER:TOTALERRORCODE=" + ErrorCode[0] + "*;MASTER:FPYCODE=" + "FAIL" + ";*;MASTER:FIXTUREID=" + fixname + ";*;MASTER:DESCRIPTION=" + ErrorCode[1] + ";*;MASTER:MonitorAgentVer=VW20151102.01;*;";
                    }

                    if (Check_dutoffline(jObject))
                    {
                        DB_Info = "SET SF_CFG_CHK=PASS;$;ErrorCode=OFFLINE;$;";
                        Status_Fcode[1] = "OFFLINE";
                    }
                    else
                    {
                        //Console.WriteLine("connectfinal line 643 [InputStr]: {0}",InputStr);
                        DB_Info = Shopfloor.DBInfo_FATP(dut_sn, station, "QDW", InputStr, AnalysisFATPSFDB(dut_sn), strMD5, station);
                    }
                    if (DB_Info.Contains("SET SF_CFG_CHK=PASS"))
                    {
                        if (Status_Fcode[1] != "PASS" && Status_Fcode[1] != "TBD" && Status_Fcode[1] != "")
                        {
                            RecordLog.WriFPY(dut_sn, station, fixname, Status_Fcode[1], Shopfloor.Get_str("SET SKU=", ";$;", Query_Info), Shopfloor.Get_str("SET PN=", ";$;", Query_Info) + "," + Shopfloor.Get_str("SET PQCFail_ID=", ";$;", DB_Info));
                        }
                        return "{\"result\": \"PASS\", \"message\": \"OK\", \"data\":{\"next_action\":\"" + Shopfloor.Get_str("SET NextSation=", ";$;", Query_Info) + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"" + final_run + "\"}}";
                    }
                    else
                    {
                        if (dut_sn == GetConfigValue.FATP_dummy_sn)
                        { return DummyConnectFinal(); }
                        return "{\"result\": \"FAIL\", \"message\": \"" + DB_Info + "\", \"data\":{\"next_action\":\"" + next_station + "\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
                    }
                }
            }
            catch (Exception error_ConnectFinal)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_ConnectFinal.Message, "error_ConnectFinal");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_ConnectFinal.Message);
                return "{\"result\": \"FAIL\", \"message\": \"" + RequestStr + " " + error_ConnectFinal.Message + "\", \"data\":{\"next_action\":\"\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"False\"}}";
            }
        }
        /// <summary>
        /// Check device whether offline. Mainly for Mclean/Touch's Touch/LED/MMI
        /// </summary>
        /// <param name="jObject"> Request str description json </param>
        /// <returns> if device offline,return true. else return false </returns>
        private static bool Check_dutoffline(JObject jObject)
        {
            try
            {
                if (GetKeyValue(jObject, "dut_offline") == "YES")
                {
                    return true;
                }
            }
            catch (Exception getoffline)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + getoffline.Message, "getoffline");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + getoffline.Message);
            }
            return false;
        }

        /// <summary>
        /// Check special Item (Check_hash_diff) of Sabrina FATP-FCHECK station. if hash diff more than 120, Send Fail to shopfloor.
        /// </summary>
        /// <param name="jObject"> Request str -> description json </param>
        /// <param name="station"> The station must is FATP-FCHECK</param>
        /// <returns> if hash diff more than 120,return true. else return false </returns>
        private static bool Check_hash_diff(JObject jObject, string station)
        {
            try
            {
                if (station == "FATP-FCHECK" && jObject.ToString().Contains("Check_hash_diff"))
                {
                    if ((double)((JObject)(jObject.GetValue("description"))).GetValue("Check_hash_diff") >= 120)
                    {
                        return true;
                    }
                }
            }
            catch (Exception hashdiff)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + hashdiff.Message, "hashdiff");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + hashdiff.Message);
            }
            return false;
        }

        /// <summary>
        /// Get PWM Value of Abbey QT station.
        /// </summary>
        /// <param name="jObject">Request str>description>PANDORA>PWM_VALUE value </param>
        /// <param name="station"> The station must is FATP-QT </param>
        /// <returns> return PWM value </returns>
        private static string GetPWM(JObject jObject, string station)
        {
            try
            {
                if (station == "FATP-QT" && jObject.ContainsKey("PANDORA") && jObject.ToString().Contains("PWM_VALUE"))
                {
                    return JObject.Parse(GetKeyValue(jObject, "PANDORA")).GetValue("PWM_VALUE").ToString();
                }
            }
            catch (Exception getpwm)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + getpwm.Message, "getpwm");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + getpwm.Message);
            }
            return "";
        }

        /// <summary>
        /// Get json value
        /// </summary>
        /// <param name="jObject"> json str </param>
        /// <param name="Key"> Key </param>
        /// <returns> key value </returns>
        public static string GetKeyValue(JObject jObject, string Key)
        {
            if (jObject.ContainsKey(Key))
            {
                return jObject.GetValue(Key).ToString();
            }
            return "";
        }

        /// <summary>
        /// Check staion with Config whether need to upload data to shopfloor
        /// </summary>
        /// <param name="station"> Request station </param>
        /// <returns> if station need to upload data to shopfloor,return true. </returns>
        private static bool Check_uploadStation(string station)
        {
            foreach (var Station in GetConfigValue.UploadStations)
            {
                if (Station == station)
                { return true; }
            }
            return false;
        }
        /// <summary>
        /// Check staion with Config whether need to upload data to shopfloor at SMT
        /// </summary>
        /// <param name="station"></param>
        /// <returns></returns>
        private static bool Check_BU10uploadStation(string station)
        {
            foreach (var Station in GetConfigValue.BU10UploadStations)
            {
                if (Station == station)
                { return true; }
            }
            return false;
        }
        /// <summary>
        /// Check QAStation and upload description data to shopfloor
        /// </summary>
        /// <param name="station">Request station</param>
        /// <returns></returns>
        private static bool Check_QAStations(string station, string project)
        {
            if (station == "OQC" && (project == "T6" || project == "K6"))
            {
                return false;
            }
            foreach (var Station in GetConfigValue.QAStations)
            {
                if (Station == station)
                { return true; }
            }
            return false;
        }
        /// <summary>
        /// Check the station: LCOS,PCOS,OOBE
        /// </summary>
        /// <param name="station"></param>
        /// <param name="project"></param>
        /// <returns></returns>
        private static bool Check_UploadQAStations(string station)
        {
            if((station == "LCOS") || (station == "PCOS") || (station == "OOBE") || (station == "OQC") || (station == "EUT"))
            {
                return true;
            }
            else if ((station.IndexOf("LCOS") != -1) || (station.IndexOf("PCOS") != -1) || (station.IndexOf("OOBE") != -1))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// Check SMT Status of test result.
        /// </summary>
        /// <param name="status"> Clifford Request status </param>
        /// <param name="FailCout"> The shopfloor Fail Count </param>
        /// <param name="ErrorCode"> Fail Item ErrorCode </param>
        /// <returns>return [ status, ErrorCode ]</returns>
        private static string[] SMT_Check_Status(string status, string FailCout, string ErrorCode, string project)
        {
            string[] response = { "PASS", "PASS" };
            if (status == "SCOF_PASS")
            {
                response[1] = response[0] = "PASS";
                return response;
            }
            switch (FailCout)
            {
                case "0":
                    if (status.Contains("PASS"))
                    { response[0] = "PASS"; response[1] = "PASS"; }
                    else
                    { response[0] = "TBD"; response[1] = ""; }
                    break;
                case "1":
                    if (status.Contains("PASS"))
                    { response[0] = "RETEST"; response[1] = "PASS"; }
                    else
                    { response[0] = "TBD"; response[1] = ""; }
                    break;
                case "2":
                    if (status.Contains("PASS"))
                    { response[0] = "NTF"; response[1] = "PASS"; }
                    else
                    { response[0] = "FAIL"; response[1] = ErrorCode.Substring(0, 5); }
                    break;
                default:
                    if (status.Contains("PASS"))
                    { response[0] = "NTF"; response[1] = "PASS"; }
                    else
                    { response[0] = "FAIL"; response[1] = ErrorCode.Substring(0, 5); }
                    break;
            }
            return response;
        }
        /// <summary>
        /// check SMT true fail project
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        private static bool Check_project(string project)
        {
            string[] strArray = GetConfigValue.GetSMTTrueFAILPro().Split(';');
            for (int index = 0; index < strArray.Length; ++index)
            {
                if (strArray[index].Length >= 2 && strArray[index] == project)
                    return true;
            }
            return false;
        }
        /// <summary>
        /// check if the BU10 test projects
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        private static bool Check_BU10project(string project)
        {
            string[] Projects = GetConfigValue.BU10Projects;
            if (Projects.Contains(project))
                return true;
            return false;
        }
        /// <summary>
        /// Check Status of test result.
        /// </summary>
        /// <param name="status"> Clifford Request status </param>
        /// <param name="FailCout"> The shopfloor Fail Count </param>
        /// <param name="ErrorCode"> Fail Item ErrorCode </param>
        /// <returns>return [ status, FPYcode ]</returns>
        private static string[] Check_Status(string status, string FailCout, string ErrorCode, string project)
        {
            string[] response = { "PASS", "PASS" };
            if (status == "SCOF_PASS")
            {
                response[0] = "PASS";
                response[1] = "SCOF_PASS"; //response[0] = "SCOF_PASS";
                return response;
            }
            switch (FailCout)
            {
                case "0":
                    if (status.Contains("PASS"))
                    { response[0] = "PASS"; response[1] = "PASS"; }
                    else
                    { response[0] = "TBD"; response[1] = ""; }
                    break;
                case "1":
                    if (status.Contains("PASS"))
                    { response[0] = "PASS"; response[1] = "RETEST"; }
                    else
                    { response[0] = "TBD"; response[1] = ""; }
                    break;
                case "2":
                    if (status.Contains("PASS"))
                    { response[0] = "PASS"; response[1] = "NTF"; }
                    else
                    {
                        response[1] = "FAIL";
                        if (ErrorCode == "FAIL;")
                        { response[0] = "FAIL"; }
                        else { response[0] = ErrorCode.Substring(0, 5); }
                    }
                    break;
                default:
                    if (status.Contains("PASS"))
                    { response[0] = "PASS"; response[1] = "PASS"; }
                    else
                    { response[0] = "PASS"; response[1] = "PASS"; }//??????????
                    break;
            }
            return response;
        }

        /// <summary>
        /// Get Error Code from TotalErrorCode
        /// </summary>
        /// <param name="DUT_SN"> device serial number </param>
        /// <param name="station"> request station id </param>
        /// <param name="FIXTURE"> request fixture id </param>
        /// <param name="description"> request description str </param>
        /// <returns> return [ErrorCode, AllFailItems] </returns>
        public static string[] FindErrorCode(string DUT_SN, string station, string FIXTURE, string description)
        {
            string[] response = { "FAIL;", "" };
            try
            {
                JObject FailItems = JObject.Parse(description);
                if (!TotalErrorCode.ContainsKey(station))
                { return response; }
                JObject station_totalErrorCode = (JObject)TotalErrorCode.GetValue(station);
                int count_error = 0;
                foreach (var FailItem in FailItems)
                {
                    string failitem = FailItem.Key.ToString();
                    if (station_totalErrorCode.ContainsKey(failitem))
                    {
                        if (response[0] == "FAIL;")
                        {
                            response[0] = "";
                        }
                        if (!(response[0].Contains(GetKeyValue(station_totalErrorCode, failitem))) && GetKeyValue(station_totalErrorCode, failitem) != "")
                        {
                            count_error++;
                            response[0] += GetKeyValue(station_totalErrorCode, failitem) + ";";
                        }
                    }
                    response[1] += failitem + ";";
                    if (count_error > 30)
                        break;
                }
                if (response[1].Length > 6000)
                { response[1] = response[1].Substring(0, 6000); }
            }
            catch (Exception catcherrorcode)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + catcherrorcode.Message, "catcherrorcode");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + catcherrorcode.Message);
            }
            return response;
        }
        /// <summary>
        /// Get Error Code from BU10's test description
        /// </summary>
        /// <param name="DUT_SN"> device serial number </param>
        /// <param name="station"> request station id </param>
        /// <param name="FIXTURE"> request fixture id </param>
        /// <param name="description"> request description str </param>
        /// <returns> return [ErrorCode, AllFailItems] </returns>
        public static string[] FindBU10ErrorCode(string DUT_SN, string station, string FIXTURE, string description)
        {
            string[] response = { "FAIL;", "" }; // response[0]: failitem对应的total 5码errorcode, fail value；response[1]: failitems
            try
            {
                // {'description': { 'check_lan_mac': '123456'}}
                JObject FailItems = JObject.Parse(description);
                int count_error = 0;
                foreach (var FailItem in FailItems)
                {
                    string failitem = FailItem.Key.ToString();
                    if (response[0] == "FAIL;")
                    {
                        response[0] = "";
                    }
                    count_error++;
                    response[0] += FailItem.Value.ToString() + ";";
                    response[1] += failitem + ";";
                    if (count_error > 30)
                        break;
                }
                if (response[1].Length > 6000)
                { response[1] = response[1].Substring(0, 6000); }
            }
            catch (Exception GetErrorCode)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + GetErrorCode.Message, "GetErrorCode");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + GetErrorCode.Message);
            }
            if (response[0].Length < 5)
            {
                response[0] = "EMPTY;";
            }
            return response;
        }
        /// <summary>
        /// Upload string to SFC of some stations(provision)
        /// </summary>
        /// <param name="description">request description key</param>
        /// <returns>Uploaddata string</returns>
        private static string strUploadSFC(JObject description)
        {
            string Response = "";
            foreach (JToken child in description.Children())
            {
                var property1 = child as JProperty;
                string key_name = GetKeyValue(StationUpload, property1.Name);
                if (key_name != "")
                {
                    if (property1.Name == "PANDORA")
                    {
                        JObject pandoras = JObject.Parse(description.GetValue("PANDORA").ToString());
                        JObject jObject = JObject.Parse(GetKeyValue(StationUpload, "PANDORA"));
                        foreach (JToken grandChild in pandoras.Children())
                        {
                            var property = grandChild as JProperty;
                            if (property != null)
                            {
                                //Response += ";*;MASTER:" + GetKeyValue(pandoras, property.Name) + "=" + property.Value;
                                //Console.WriteLine(jObject.ToString());
                                //Console.WriteLine(jObject.GetValue(property.Name));
                                Response += ";*;MASTER:" + GetKeyValue(jObject, property.Name) + "=" + property.Value;
                                // Console.WriteLine(property.Name + ":" + property.Value);
                            }
                        }
                    }
                    else
                    {
                        Response += ";*;MASTER:" + key_name + "=" + property1.Value;
                    }
                }
            }
            //Console.WriteLine(Response);
            return Response;
        }
        /// <summary>
        /// Upload string to SFC of BU10 projects' station which need to upload.(FWT2)
        /// </summary>
        /// <param name="description">request description key</param>
        /// <returns>Uploaddata string</returns>
        private static string strBU10UploadSFC(JObject description,string Project, string Station)
        {
            string Response = "";
            JObject Result_dct = JObject.Parse(description.ToString());
            string[] variables = GetConfigValue.GetUploadBU10Variables(Project,Station);
            if(variables.Length != 1 && variables[0] != "")
            {
                foreach (string key in variables)
                {
                    if(key != "")
                    {
                        if (GetKeyValue(Result_dct, key) != "")
                        {
                            if (Check_BU10uploadStation(Station))
                            {
                                Response += ";$;" + key + "=" + GetKeyValue(Result_dct, key);
                            }
                            else
                            {
                                Response += ";*;MASTER:" + key + "=" + GetKeyValue(Result_dct, key);
                            }
                        }
                        else
                        {
                            return "";
                        }
                    }
                }
                return Response;
            }
            else
            {
                return "SKIP";
            }
        }
        /// <summary>
        /// Upload string to SFC of some stations(LCOS/PCOS/PCOS)
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        private static string[] strQAUploadSFC(JObject description)
        {
            string[] Response = { "","" }; // Response[0] = "userid", Response[1] = "forminfo"(PANDORA中没有则返回空)
            try
            {
                JObject pandoraObject = JObject.Parse(GetKeyValue(description, "PANDORA"));
                foreach (JToken child in pandoraObject.Children())
                {
                    var property1 = child as JProperty;
                    if (property1.Name == "UID")
                    {
                        Response[0] = ";*;" + property1.Name + "=" + property1.Value + ";*;";
                    }
                    if (property1.Name == "CheckForm")
                    {
                        JObject checkform = JObject.Parse(pandoraObject.GetValue("CheckForm").ToString());
                        foreach (JToken checkformchild in checkform.Children())
                        {
                            var property = checkformchild as JProperty;
                            if (property != null)
                            {
                                Response[1] += ";*;MASTER:" + property.Name + "=" + property.Value.ToString().Trim();
                            }
                        }
                    }
                }
            }
            catch (Exception QAUploadError)
            {
                Console.WriteLine("[QAUploadError]: {0}", QAUploadError);
            }
            return Response;
        }
        /// <summary>
        /// Get QA errorcode from the description 
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        private static string[] GetQAErrorCode(JObject description)
        {
            string[] errorcode = { "ErrorCode", "", "FAIL" };
            try
            {
                //string dct = description.GetValue("description").ToString();
                string dct = description.ToString();
                JObject jobject = JObject.Parse(dct);
                foreach (var property in jobject.Properties())
                {
                    string key = property.Name;
                    JToken value = property.Value;
                    if (key == errorcode[0].ToString())
                    {
                        errorcode[1] = value.ToString();
                        return errorcode;
                    }
                }
            }
            catch (Exception GetQAErrorCode)
            {
                Console.WriteLine("[GetQAErrorCode Error]: {0}", GetQAErrorCode);
            }
            return errorcode;
        }
        /// <summary>
        /// Get the errorcode from the pandora of description
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        private static string[] GetPandoraErrorCode(JObject description)
        {
            string[] errorcode = { "ErrorCode", "", "FAIL" }; // errorcode[1]：fail 5码, errorcode[2]：PASS or FAIL(FPYCode)
            try
            {
                //{ "ErrorCode": "UID!A1060930!ErrorCode!12345"}
                string[] all_errorcode = GetKeyValue(description, "ErrorCode").Split('!');
                //Console.WriteLine("0:{0},1:{1},2:{2},3:{3}", all_errorcode[0], all_errorcode[1], all_errorcode[2], all_errorcode[3]);
                if (all_errorcode[0] == "UID")
                {
                    errorcode[0] = ";*;" + all_errorcode[0].Trim() + "=" + all_errorcode[1].Trim() + ";*;";
                    errorcode[1] = all_errorcode[3].Trim();
                }
            }
            catch (Exception GetPandoraErrorCode)
            {
                Console.WriteLine("[GetPandoraErrorCode Error]: {0}", GetPandoraErrorCode);
            }
            return errorcode;
        }
        /// <summary>
        /// Link SFC upload info with clifford upload info
        /// </summary>
        private static void SetSFCUpload()
        {
            JObject Pandora = new JObject();

            for (int i = 0; i < strCli.Count(); i++)
            {
                if (strCli[i].Contains("PANDORA:"))
                {
                    Pandora.Add(strCli[i].Split(':')[1], strQMS[i]);
                }
                else
                {
                    StationUpload.Add(strCli[i], strQMS[i]);
                }
            }
            if (Pandora != null)
            {
                StationUpload.Add("PANDORA", Pandora);
            }
            // Console.WriteLine(StationUpload.ToString());
        }

        /// <summary>
        /// Get TotalErrorCode from Config
        /// </summary>
        public static void Get_ErrorCode()
        {
            try
            {
                //string path = System.Environment.CurrentDirectory + "\\ErrorCode";
                foreach (var station_file in Directory.GetFiles(System.Environment.CurrentDirectory + "\\ErrorCode"))
                {
                    JObject station = new JObject();
                    foreach (var lines in File.ReadAllLines(station_file))
                    {
                        string[] line = lines.Split(',');
                        if (line[0] == "NO")
                        { continue; }
                        if (line.Length >= 3 && line[1] != "" && line[2] != "" && line[0] != "")
                        {
                            if (!station.ContainsKey(line[1]))
                            {
                                station.Add(line[1], line[2]);
                            }
                        }
                    }
                    if (station.Count > 0)
                    {
                        TotalErrorCode.Add(station_file.Substring(station_file.LastIndexOf("\\") + 1, station_file.LastIndexOf(".") - station_file.LastIndexOf("\\") - 1), station);
                    }
                }
                //Console.WriteLine(TotalErrorCode.ToString());
            }
            catch (Exception geteroorcode)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + geteroorcode.Message, "geteroorcode");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + geteroorcode.Message);
            }
        }

        /// <summary>
        /// Get Line ID from request fixture id
        /// </summary>
        /// <param name="Fixture_id">Request Fixture id</param>
        /// <returns> return Line id </returns>
        public static string split_lineid(string Fixture_id)
        {
            try
            {
                return Fixture_id.Substring(Fixture_id.IndexOf("-") + 1, 3);
            }
            catch (Exception getlineid)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + getlineid.Message, "getlineid");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + getlineid.Message);
            }
            return "";
        }

        /// <summary>
        /// Split SF info 
        /// </summary>
        /// <param name="SF_Info"></param>
        /// <returns></returns>
        public static string Split_SF(string SF_Info)
        {
            string SF_list = "";
            try
            {
                Dictionary<string, string> sfdic = new Dictionary<string, string>();
                string[] split_info = SF_Info.Split(new string[] { ";$;" }, StringSplitOptions.None);
                foreach (var item in split_info)
                {
                    //Console.WriteLine(item);
                    if (item.Length < 4)
                    { continue; }
                    try
                    {
                        string name = item.Substring(4);
                        string[] key_value = name.Split('=');
                        if (key_value[0].Contains("COUNTRY"))
                        {
                            SF_list += "\"" + key_value[0].Replace("COUNTRY", "Country") + "\" : \"" + key_value[1] + "\", ";
                        }
                        SF_list += "\"" + key_value[0] + "\" : \"" + key_value[1] + "\", ";
                        try
                        {
                            if (key_value[0].Trim().Length == 0) continue;
                            sfdic[key_value[0].Trim()] = key_value[1].Trim();
                        }
                        catch (Exception x)
                        {
                            Console.WriteLine("{\"result\": \"FAIL\", \"message\": \"line 671" + x.Message + "\"}");
                        }
                    }
                    catch (Exception splitsfinfo)
                    {
                        RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + splitsfinfo.Message, "splitsfinfo");
                        Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + splitsfinfo.Message);
                    }
                }
            }
            catch (Exception SplitSFC)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + SplitSFC.Message, "SplitSFC");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + SplitSFC.Message);
            }
            return SF_list;
        }

        /// <summary>
        /// Check SOCF satus
        /// </summary>
        /// <param name="project">project id</param>
        /// <param name="station">SF station</param>
        /// <returns></returns>
        public static string Check_SCOF(string project, string station)
        {
            string[] scofs = GetConfigValue.GetSCOF(project).Split(';');
            for (int i = 0; i < scofs.Length; i++)
            {
                if (scofs[i].ToUpper() == station.ToUpper())
                {
                    return "ON";
                }
            }
            return "OFF";
        }
        /// <summary>
        /// Get COF status from config file
        /// </summary>
        /// <param name="project">project id</param>
        /// <param name="station">SF station</param>
        /// <returns></returns>
        public static string Check_COF(string project, string station)
        {
            string[] scofs = GetConfigValue.GetCOF(project).Split(';');
            for (int i = 0; i < scofs.Length; i++)
            {
                if (scofs[i].ToUpper() == station.ToUpper())
                {
                    return "ON";
                }
            }
            return "OFF";
        }
        /// <summary>
        /// Get retest policy from config
        /// </summary>
        /// <param name="project">request project id</param>
        /// <returns> retest policy </returns>
        public static string Check_RetestRule(string project)
        {
            return GetConfigValue.GetRetestRule(project);
        }

        /// <summary>
        /// analysis station id and get SFC routing id 
        /// </summary>
        /// <param name="station_id">station_id value of the request</param>
        /// <param name="jObject">station_id value of the request</param>
        /// <returns>SFC routing id</returns>
        public static string AnalysisStation(string station_id, JObject jObject)
        {
            station_id = station_id.Replace(" ", "");
            string station = station_id;
            try
            {
                if (station_id.Contains("SMT-RF-COND-"))
                {
                    station_id = station_id.Replace("SMT-RF-COND-", "SMT-RF-COND_");
                }
                string[] stations = station_id.Split('_');
                if (stations.Length >= 4)
                {
                    station = stations[2];
                }
                else
                {
                    station = station_id.Substring(0, station_id.IndexOf("-"));
                }
                if (station.Contains("SMT-BFT"))
                {
                    if (station.Substring(0, 7) == "SMT-BFT")
                    {
                        station = "SMT-BFT";
                    }
                }
            }
            catch (Exception anasta)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + anasta.Message, "anasta");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + anasta.Message);
            }
            return station;
        }
        /// <summary>
        /// 从station_id中获取机种名
        /// </summary>
        /// <param name="station_id">站别名</param>
        /// <param name="jObject"></param>
        /// <returns></returns>
        public static string AnalysisProject(string station_id, JObject jObject)
        {
            station_id = station_id.Replace(" ", "");
            string project = station_id;
            try
            {
                string[] stations = station_id.Split('_');
                if (stations.Length >= 4)
                {
                    project = stations[0];
                }
                else
                {
                    project = station_id.Substring(0, station_id.IndexOf("-"));
                }
            }
            catch (Exception ProjectError)
            {
                Console.WriteLine("[Get project fail]: {0}", ProjectError);
            }
            return project;
        }
        /// <summary>
        /// Check test rule AAB  ABC by station_id string
        /// </summary>
        /// <param name="SFInfo"></param>
        /// <param name="dut_sn"></param>
        /// <param name="fixture_id"></param>
        /// <param name="project"></param>
        /// <returns></returns>
        public static string CheckTestRule_new(string SFInfo, string dut_sn, string fixture_id)
        {
            string fix_id_1 = Shopfloor.Get_str("1FixtureID=", ";$;", SFInfo);
            string fix_id_2 = Shopfloor.Get_str("2FixtureID=", ";$;", SFInfo);
            bool AAB = false, ABC = false;
            string project = "DEFAULT";
            try
            {
                project = fixture_id.Split('_')[0];
            }
            catch (Exception)
            {
            }
            string rule = Check_RetestRule(project);
            switch (rule)
            {
                case "AAB":
                    string projectrule = GetConfigValue.GetAABReTestRule(project);
                    if (projectrule != "")
                    {
                        if (projectrule.ToUpper()=="ALL")
                        {
                            AAB = true;
                        }
                        foreach (string item in projectrule.Split(';'))
                        {
                            if (fixture_id.Contains(item))
                            {
                                AAB = true;
                            }
                        }
                    }
                    break;
                case "ABC":
                    string projectrule_ABC = GetConfigValue.GetABCReTestRule(project);
                    if (projectrule_ABC != "")
                    {
                        if (projectrule_ABC.ToUpper() == "ALL")
                        {
                            ABC = true;
                        }
                        foreach (string item in projectrule_ABC.Split(';'))
                        {
                            if (fixture_id.Contains(item))
                            {
                                ABC = true;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
            switch (Shopfloor.Get_str("FailCount=", ";$;", SFInfo))
            {
                case "1":
                    if (fix_id_1 != fixture_id && AAB)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + "The device fail once in " + fixture_id + ", Please test in " + fix_id_1 + " again." + "\"}";
                    }
                    break;
                case "2":
                    if (fix_id_1 == fixture_id && AAB)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + "The device alreadly fail 2 times in this fixture, Please change fixture test. " + fixture_id + "\"}";
                    }
                    else if (fix_id_2 == "" && fix_id_1 == fixture_id && ABC)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + "Please change the test fixture. The present fixture_id is " + fixture_id + "\"}";
                    }
                    break;
                default:
                    break;
            }
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
        }


        /// <summary>
        /// Check test rule AAB  ABC
        /// </summary>
        /// <param name="SFInfo"> shopfloor QueryData </param>
        /// <param name="dut_sn"> device serial number </param>
        /// <param name="fixture_id"> request fixture id </param>
        /// <returns> return Check result </returns>
        public static string CheckTestRule(string SFInfo,string dut_sn, string fixture_id)
        {
            //string test_count = Shopfloor.Get_str("FailCount=", ";$;", SFInfo);
            string fix_id_1 = Shopfloor.Get_str("1FixtureID=", ";$;", SFInfo);
            string fix_id_2 = Shopfloor.Get_str("2FixtureID=", ";$;", SFInfo);
            string SF_PN = Shopfloor.Get_str("PN=", ";$;", SFInfo);
            bool AAB = false, ABC = false;
            for (int i = 0; i < GetConfigValue.Check_AAB.Length; i++)
            {
                if (SF_PN.Length > 5)
                {
                    break;
                }
                if (SF_PN.Substring(0, 5).Contains(GetConfigValue.Check_AAB[i]) && GetConfigValue.Check_AAB[i].Trim().Length > 1)
                {
                    AAB = true;
                }
            }
            for (int i = 0; i < GetConfigValue.Check_ABC.Length; i++)
            {
                if (SF_PN.Length > 5)
                {
                    break;
                }
                if (SF_PN.Substring(0, 5).Contains(GetConfigValue.Check_ABC[i]) && GetConfigValue.Check_ABC[i].Trim().Length > 1)
                {
                    ABC = true;
                }
            }
            switch (Shopfloor.Get_str("FailCount=", ";$;", SFInfo))
            {
                case "1":
                    if (fix_id_1 != fixture_id && AAB)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + "The device fail once in " + fixture_id + ", Please test in " + fix_id_1 + " again." + "\"}";
                    }
                    break;
                case "2":
                    if (fix_id_1 == fixture_id && AAB)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + "The device alreadly fail 2 times in this fixture, Please change fixture test. " + fixture_id + "\"}";
                    }
                    else if (fix_id_2 == "" && fix_id_1 == fixture_id && ABC)
                    {
                        return "{\"result\": \"FAIL\", \"message\": \"" + "SN=" + dut_sn + "Please change the test fixture. The present fixture_id is " + fixture_id + "\"}";
                    }
                    break;
                default:
                    break;
            }

            return "{\"result\": \"PASS\", \"message\": \"OK\"}";
        }
        /// <summary>
        /// manage user insert delete query
        /// </summary>
        /// <param name="user_id"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string[] Manage_User(string user_id, string password)
        {
            string[] result = { "FAIL",""};
            switch (user_id.Substring(0,2))
            {
                case "AD":
                    result = Check_OPID.Add_user(user_id, password, user_id.Substring(2,1));
                    break;
                case "UP":
                    result = Check_OPID.Update_user(user_id, password, user_id.Substring(2, 1));
                    break;
                case "DE":
                    result = Check_OPID.Delete_user(user_id, password, user_id.Substring(2, 1));
                    break;
                case "QU":
                    result = Check_OPID.Query_User();
                    break;
                default:
                    result[0] = "FAIL"; result[1] = "UserID format error";
                    break;
            }
            return result;
        }

        /// <summary>
        /// check FATP SF DB type
        /// </summary>
        /// <param name="DUT_SN">device id</param>
        /// <returns>SFDB Interface and FATP_DBserver IP</returns>WIP1106ADTE4GC
        public static string AnalysisFATPSFDB(string DUT_SN)
        {
            try
            {
                if ((DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(7, 1).ToUpper() == "C" && DUT_SN.Length == 13) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(8, 1).ToUpper() == "C" && DUT_SN.Length == 14)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(10, 2).ToUpper() == "AK" && DUT_SN.Length == 17) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(11, 2).ToUpper() == "AK" && DUT_SN.Length == 18)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(10, 2).ToUpper() == "DD" && DUT_SN.Length == 17) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(11, 2).ToUpper() == "DD" && DUT_SN.Length == 18)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(10, 2).ToUpper() == "E4" && DUT_SN.Length == 17) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(11, 2).ToUpper() == "E4" && DUT_SN.Length == 18)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(10, 2).ToUpper() == "GN" && DUT_SN.Length == 17) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(11, 2).ToUpper() == "GN" && DUT_SN.Length == 18)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(7, 2).ToUpper() == "AD" && DUT_SN.Length == 14) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(8, 2).ToUpper() == "AD" && DUT_SN.Length == 15)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(7, 2).ToUpper() == "GU" && DUT_SN.Length == 14) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(8, 2).ToUpper() == "GU" && DUT_SN.Length == 15)
                            || (DUT_SN.Substring(0, 3).ToUpper() == "WIP" && DUT_SN.Substring(10, 2).ToUpper() == "H4" && DUT_SN.Length == 17) || (DUT_SN.Substring(0, 4).ToUpper() == "BWIP" && DUT_SN.Substring(11, 2).ToUpper() == "H4" && DUT_SN.Length == 18))
                {
                    return "SEL2";
                }
            }
            catch (Exception anaDBtype)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + anaDBtype.Message, "anaDBtype");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + anaDBtype.Message);
            }
            return "SEL";
        }

        /// <summary>
        /// Check SN rule if SN is Bsn, remove B
        /// </summary>
        /// <param name="SN">request SN</param>
        /// <returns>SN</returns>
        public static string DUT_SN_init(string SN)
        {
            try
            {
                if (SN.Substring(0, 4) == "BWIP")
                {
                    return SN.Substring(1);
                }
            }
            catch (Exception initSN)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + initSN.Message, "initSN");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + initSN.Message);
            }
            return SN;
        }

        /// <summary>
        /// check dut_id and station_id rule
        /// </summary>
        /// <param name="dut_sn">request dut_id </param>
        /// <param name="station_id">request station_id</param>
        /// <returns>check result (true/false)</returns>
        public static bool CheckRequest(string dut_sn,string station_id)
        {
            dut_sn = dut_sn.Replace(" ", "");
            station_id = station_id.Replace(" ", "");
            if (dut_sn.Length > 5 && station_id !="")
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// return Error messeage to Clifford
        /// </summary>
        /// <param name="type">message type</param>
        /// <param name="Mes">Message</param>
        /// <returns>Error messeage by json</returns>
        public static string RetureError(string type, string Mes = "")
        {
            switch (type)
            {
                case "request":
                    return "{\"result\": \"FAIL\", \"message\": {\"RequestError\":" + Mes + "}}";
                default:
                    break;
            }
            return "";
        }

        /// <summary>
        /// Check station local (FATP/SMT)
        /// </summary>
        /// <param name="station">Station</param>
        /// <returns>true is SMT, false is FATP</returns>
        public static bool Check_Station(string station)
        {
            foreach (string SMT in GetConfigValue.SMT_Stations)
            {
                if (SMT == "")
                {
                    continue;
                }
                if (station.ToUpper()==SMT.ToUpper())
                {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// translate info to QMS input format
        /// </summary>
        /// <param name="dut_sn">dut sn</param>
        /// <param name="station">SF station id</param>
        /// <param name="fixture_id">fixture id</param>
        /// <returns></returns>
        public static string Get_InputStr(string dut_sn, string station, string fixture_id, string data_type = "")
        {
            string InputStr = $"SN={dut_sn};$;nextstation={station};$;station=QueryData;$;FixtureID={fixture_id};$;MonitorAgentVer=VW20220730.0248;$;";
            if (Check_SNtype(dut_sn))
            {
                InputStr = $"MB_NUM={dut_sn};$;nextstation={station};$;station=QueryData;$;FixtureID={fixture_id};$;MonitorAgentVer=VW20220730.0248;$;";
            }
            if (fixture_id.Split('_')[0].ToUpper() == "T6" && (station == "SA-AOI-BASE" || station == "SA-QAOI-BASE") && (dut_sn.Length != 14 && dut_sn.Length != 17))
            {
                InputStr = $"BATT_SN={dut_sn};$;nextstation={station};$;station=QueryData;$;FixtureID={fixture_id};$;MonitorAgentVer=VW20220730.0248;$;";
            }
            if (data_type == "GET_DUT_SN")
            {
                InputStr = $"DSN={dut_sn};$;nextstation={station};$;station=QueryData;$;FixtureID={fixture_id};$;MonitorAgentVer=VW20220730.0248;$;";
            }
            return InputStr;
        }
        /// <summary>
        /// Check SN type(MLB_SN/SN)
        /// </summary>
        /// <param name="dut_id">Request SN</param>
        /// <returns>if Request SN is MLB_SN return true, else return false</returns>
        public static bool Check_SNtype(string dut_id)
        {
            try
            {
                string type_sn = dut_id.Substring(0, 3).ToUpper();
                if (type_sn == "QCM" || type_sn == "1HF" || type_sn == "105")
                {
                    return true;
                }
            }
            catch (Exception SNmlb)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + SNmlb.Message, "SNmlb");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + SNmlb.Message);
            }
            return false;
        }

        /// <summary>
        /// dummy SN check connect API for software verify
        /// </summary>
        /// <returns> return pass to clifford </returns>
        private static string DummyConnect()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            //return "{\"result\": \"PASS\", \"message\": \"OK\",\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
            return "{\"result\": \"PASS\", \"message\": {\"SCOF\": \"" + GetConfigValue.SMT_dummy_sn_scof + "\", \"scof\": \"" + GetConfigValue.SMT_dummy_sn_scof + "\"},\"data\": {\"sf_time\": " + Convert.ToInt64(ts.TotalMilliseconds).ToString() + "}}";
        }
        /// <summary>
        /// get time
        /// </summary>
        /// <returns></returns>
        private static string getTime()
        {
            return DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ssZ");
        }
        /// <summary>
        /// dummy SN check connectfinal API for software verify
        /// </summary>
        /// <returns> return pass to clifford </returns>
        private static string DummyConnectFinal()
        {
            return "{\"result\": \"PASS\", \"message\": \"Test OK\", \"data\":{\"next_action\":\"Dummy\", \"check_in_time\": \"" + getTime() + "\", \"final_run\": \"True\"}}";
        }
        /// <summary>
        /// AnalyseFailItem and save fail log
        /// </summary>
        /// <param name="strMD5"> MD5 </param>
        /// <param name="dut_sn"> SERIAL number </param>
        /// <param name="station"> staion name </param>
        /// <param name="fixture"> fixture id </param>
        /// <param name="descript"> fail item </param>
        private static void AnalyseFailItem(string strMD5, string dut_sn, string station, string fixture, string descript)
        {
            string Fail_Item = "";
            string Fail_Item_Value = "";
            try
            {
                JObject FailItems = JObject.Parse(descript);
                foreach (var X in FailItems)
                {
                    Fail_Item += X.Key.ToString() + "\n";
                    Fail_Item_Value += X.Key.ToString() + "  " + X.Value.ToString() + "\n";
                }
                RecordLog.WriFAILitem(dut_sn, station, split_lineid(fixture), fixture, Fail_Item, Fail_Item_Value);
                if (Fail_Item.Length > 6000)
                {
                    Fail_Item = Fail_Item.Substring(0, 6000);
                }
                if (Fail_Item_Value.Length > 6000)
                {
                    Fail_Item_Value = Fail_Item_Value.Substring(0, 6000);
                }
                RecordLog.SaveFailLogToDB(strMD5, dut_sn, station, fixture, split_lineid(fixture), Fail_Item, Fail_Item_Value, RecordLog.GetTimeForDB());
            }
            catch (Exception)
            {
            }
        }
    /// <summary>
    /// 取得当前源码的哪一行
    /// </summary>
    /// <returns></returns>
    private static int GetLineNum()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileLineNumber();
        }
        /// <summary>
        /// 取当前源码的源文件名
        /// </summary>
        /// <returns></returns>
        private static string GetCurSourceFileName()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileName();
        }

        /// <summary>
        /// return string about 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="message"></param>
        /// <param name="role"></param>
        /// <param name="mars_id"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        private static string UserInfoResponse(string result, string message, string role, string mars_id, bool query = false)
        {
            if (query)
            {
                return "{\"result\": \"" + result + "\", \"message\": " + message + ", \"data\":{\"role\": \"" + role + "\", \"mars_id\": \"" + mars_id + "\"}}";
            }
             return "{\"result\": \"" + result + "\", \"message\": \"" + message + "\", \"data\":{\"role\": \"" + role + "\", \"mars_id\": \"" + mars_id + "\"}}";
            
        }
    }
}
