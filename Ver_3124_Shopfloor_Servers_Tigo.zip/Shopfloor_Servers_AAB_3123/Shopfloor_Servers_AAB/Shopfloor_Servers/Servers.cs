﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;

namespace Shopfloor_Servers
{
    class Servers
    {
        private static HttpListener httpPost_Connect = new HttpListener();
        private static HttpListener httpPost_SendRecvDataSFC = new HttpListener();
        private static HttpListener httpPost_ConnectFinal = new HttpListener();
        private static HttpListener httpPost_LoginUser = new HttpListener();
        private static string ip, port;
        public static void Open_servers()
        {
            try
            {
                ip = GetConfigValue.GetIP();
                port = GetConfigValue.GetPort();
                httpPost_Connect.Prefixes.Add(@"http://" + ip + ":" + port + @"/Connect/");
                httpPost_Connect.Start();
                httpPost_SendRecvDataSFC.Prefixes.Add(@"http://" + ip + ":" + port + @"/SendRecvDataSFC/");
                httpPost_SendRecvDataSFC.Start();
                httpPost_ConnectFinal.Prefixes.Add(@"http://" + ip + ":" + port + @"/ConnectFinal/");
                httpPost_ConnectFinal.Start();
                httpPost_LoginUser.Prefixes.Add(@"http://" + ip + ":" + port + @"/UserLogin/");
                httpPost_LoginUser.Start();

                Thread Thred_httpPost_Connect = new Thread(new ThreadStart(Http_Connect));
                Thred_httpPost_Connect.Start();
                Thread Thred_httpPost_SendRecvDataSFC = new Thread(new ThreadStart(Http_SendRecvDataSFC));
                Thred_httpPost_SendRecvDataSFC.Start();
                Thread Thred_httpPost_ConnectFinal = new Thread(new ThreadStart(Http_ConnectFinal));
                Thred_httpPost_ConnectFinal.Start();
                Thread Thred_httpPost_UserLogin = new Thread(new ThreadStart(Http_UserLogin));
                Thred_httpPost_UserLogin.Start();

                Console.WriteLine(@"http://" + ip + ":" + port + @"/Connect/SendRecvDataSFC/ConnectFinal/UserLogin    already open");

                Console.WriteLine("All Class Init Finish");
            }
            catch (Exception open_server)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + open_server.Message, "open_server");
                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + open_server.Message);
            }
        }
        public static void Http_Connect()
        {
            while (true)
            {
                try
                {
                    HttpListenerContext requestContext = httpPost_Connect.GetContext();
                    Thread threadsub = new Thread(new ParameterizedThreadStart((requestcontext) =>
                    {
                        try
                        {
                            HttpListenerContext request = (HttpListenerContext)requestcontext;
                            byte[] data = new byte[request.Request.ContentLength64];
                            request.Request.InputStream.Read(data, 0, data.Length);
                            string receive_MSG = Encoding.UTF8.GetString(data);
                            string dut_sn = "ERROR_SN";
                            string RequestTime = RecordLog.GetTimeForDB();
                            string station_id = "";
                            string fixture_id = "";
                            try
                            {
                                JObject jObject = JObject.Parse(receive_MSG);
                                dut_sn = Requset.GetKeyValue(jObject, "dut_id");
                                fixture_id = Requset.GetKeyValue(jObject, "station_id");
                                station_id = Requset.AnalysisStation(fixture_id, jObject);
                            }
                            catch (Exception getinfo)
                            {
                                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message, "getinfo_connect");
                                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message);
                            }
                            string strMD5 = RecordLog.CreateMD5(dut_sn);
                            RecordLog.WriLogTxt(receive_MSG, "Request:", dut_sn);
                            string ResponseData = Requset.Connect(receive_MSG, strMD5);
                            RecordLog.WriLogTxt(ResponseData, "Response:", dut_sn);
                            RecordLog.SavaCliffordToDB(strMD5, dut_sn, station_id, fixture_id, "Connect", receive_MSG, RequestTime, ResponseData, RecordLog.GetTimeForDB(), port);
                            //Response  
                            request.Response.StatusCode = 200;
                            request.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                            request.Response.ContentType = "application/json";
                            requestContext.Response.ContentEncoding = Encoding.UTF8;
                            byte[] datas = Encoding.UTF8.GetBytes(ResponseData);
                            request.Response.ContentLength64 = datas.Length;
                            var output = request.Response.OutputStream;
                            output.Write(datas, 0, datas.Length);
                            output.Close();

                        }
                        catch (Exception x) {
                            RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + x.Message, "x_connect");
                            Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + x.Message); };
                    }));
                    threadsub.Start(requestContext);
                }
                catch (Exception httpConnect)
                {
                    RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpConnect.Message, "httpConnect");
                    Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpConnect.Message);
                }
            }
        }
        public static void Http_SendRecvDataSFC()
        {
            while (true)
            {
                try
                {
                    HttpListenerContext requestContext = httpPost_SendRecvDataSFC.GetContext();
                    Thread threadsub = new Thread(new ParameterizedThreadStart((requestcontext) =>
                    {
                        try
                        {
                            HttpListenerContext request = (HttpListenerContext)requestcontext;
                            byte[] data = new byte[request.Request.ContentLength64];
                            request.Request.InputStream.Read(data, 0, data.Length);
                            string receive_MSG = Encoding.UTF8.GetString(data);
                            string dut_sn = "ERROR_SN";
                            string RequestTime = RecordLog.GetTimeForDB();
                            string station_id = "";
                            string fixture_id = "";
                            string data_type = "";
                            try
                            {
                                JObject jObject = JObject.Parse(receive_MSG);
                                dut_sn = jObject.GetValue("dut_id").ToString();
                                fixture_id = Requset.GetKeyValue(jObject, "station_id");
                                station_id = Requset.AnalysisStation(fixture_id, jObject);
                                data_type = Requset.GetKeyValue(jObject, "data_type");
                            }
                            catch (Exception getinfo)
                            {
                                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message, "getinfo_SendRecvDataSFC");
                                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message);
                            }
                            string strMD5 = RecordLog.CreateMD5(dut_sn);
                            RecordLog.WriLogTxt(receive_MSG, "Request:", dut_sn);
                            string ResponseData = Requset.SendRecvDataSFC(receive_MSG, strMD5);
                            RecordLog.WriLogTxt(ResponseData, "Response:", dut_sn);
                            RecordLog.SavaCliffordToDB(strMD5, dut_sn, station_id, fixture_id, data_type, receive_MSG, RequestTime, ResponseData, RecordLog.GetTimeForDB(), port);
                            //Response  
                            request.Response.StatusCode = 200;
                            request.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                            request.Response.ContentType = "application/json";
                            requestContext.Response.ContentEncoding = Encoding.UTF8;
                            //byte[] buffer = System.Text.Encoding.UTF8.GetBytes("OK");
                            byte[] datas = Encoding.UTF8.GetBytes(ResponseData);
                            request.Response.ContentLength64 = datas.Length;
                            var output = request.Response.OutputStream;
                            output.Write(datas, 0, datas.Length);
                            output.Close();

                        }
                        catch (Exception x) {
                            RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + x.Message, "x_httpSendRecvDataSFC");
                            Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + x.Message); }
                    }));
                    threadsub.Start(requestContext);
                }
                catch (Exception httpSendRecvDataSFC)
                {
                    RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpSendRecvDataSFC.Message, "httpSendRecvDataSFC");
                    Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpSendRecvDataSFC.Message);
                }
            }
        }
        public static void Http_ConnectFinal()
        {
            while (true)
            {
                try
                {
                    HttpListenerContext requestContext = httpPost_ConnectFinal.GetContext();
                    Thread threadsub = new Thread(new ParameterizedThreadStart((requestcontext) =>
                    {
                        try
                        {
                            HttpListenerContext request = (HttpListenerContext)requestcontext;
                            byte[] data = new byte[request.Request.ContentLength64];
                            request.Request.InputStream.Read(data, 0, data.Length);
                            string receive_MSG = Encoding.UTF8.GetString(data);
                            string dut_sn = "ERROR_SN";
                            string RequestTime = RecordLog.GetTimeForDB();
                            string station_id = "";
                            string fixture_id = "";
                            try
                            {
                                JObject jObject = JObject.Parse(receive_MSG);
                                dut_sn = jObject.GetValue("dut_id").ToString();
                                fixture_id = Requset.GetKeyValue(jObject, "station_id");
                                station_id = Requset.AnalysisStation(fixture_id, jObject);
                            }
                            catch (Exception getinfo)
                            {
                                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message, "getinfo_httpConnectFinal");
                                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message);
                            }
                            string strMD5 = RecordLog.CreateMD5(dut_sn);
                            RecordLog.WriLogTxt(receive_MSG, "Request:", dut_sn);
                            string ResponseData = Requset.ConnectFinal(receive_MSG, strMD5);
                            RecordLog.WriLogTxt(ResponseData, "Response:", dut_sn);
                            RecordLog.SavaCliffordToDB(strMD5, dut_sn, station_id, fixture_id, "ConnectFinal", receive_MSG, RequestTime, ResponseData, RecordLog.GetTimeForDB(), port);
                            //Response  
                            request.Response.StatusCode = 200;
                            request.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                            request.Response.ContentType = "application/json";
                            requestContext.Response.ContentEncoding = Encoding.UTF8;
                            byte[] datas = Encoding.UTF8.GetBytes(ResponseData);
                            request.Response.ContentLength64 = datas.Length;
                            var output = request.Response.OutputStream;
                            output.Write(datas, 0, datas.Length);
                            output.Close();
                        }
                        catch (Exception x) {
                            RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + x.Message, "x_httpConnectFinal");
                            Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + x.Message); };
                    }));
                    threadsub.Start(requestContext);
                }
                catch (Exception httpConnectFinal)
                {
                    RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpConnectFinal.Message, "httpConnectFinal");
                    Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpConnectFinal.Message);
                }
            }
        }
        public static void Http_UserLogin()
        {
            while (true)
            {
                try
                {
                    HttpListenerContext requestLoginUser = httpPost_LoginUser.GetContext();
                    Thread threadsub = new Thread(new ParameterizedThreadStart((requestcontext) =>
                    {
                        try
                        {
                            HttpListenerContext request = (HttpListenerContext)requestcontext;
                            byte[] data = new byte[request.Request.ContentLength64];
                            request.Request.InputStream.Read(data, 0, data.Length);
                            string receive_MSG = Encoding.UTF8.GetString(data);
                            string userid = "ERROR_ID";
                            try
                            {
                                JObject jObject = JObject.Parse(receive_MSG);
                                userid = jObject.GetValue("user_id").ToString();
                            }
                            catch (Exception getinfo)
                            {
                                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message, "getinfo_LoginUser");
                                Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + "" + getinfo.Message);
                            }
                            string strMD5 = RecordLog.CreateMD5(userid);
                            RecordLog.WriLogTxt(receive_MSG, "Request:", userid);
                            string ResponseData = Requset.UserLogin(receive_MSG, strMD5);
                            //Console.WriteLine(ResponseData);
                            RecordLog.WriLogTxt(ResponseData, "Response:", userid);
                            //Response  
                            request.Response.StatusCode = 200;
                            request.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                            request.Response.ContentType = "application/json";
                            requestLoginUser.Response.ContentEncoding = Encoding.UTF8;
                            //byte[] buffer = System.Text.Encoding.UTF8.GetBytes("OK");
                            byte[] datas = Encoding.UTF8.GetBytes(ResponseData);
                            request.Response.ContentLength64 = datas.Length;
                            var output = request.Response.OutputStream;
                            output.Write(datas, 0, datas.Length);
                            output.Close();

                        }
                        catch (Exception x)
                        {
                            RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + x.Message, "x_httpLoginUser");
                            Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + x.Message);
                        }
                    }));
                    threadsub.Start(requestLoginUser);
                }
                catch (Exception httpLoginUser)
                {
                    RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpLoginUser.Message, "httpLoginUser");
                    Console.WriteLine("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + httpLoginUser.Message);
                }
            }
        }

        /// <summary>
        /// 取得当前源码的哪一行
        /// </summary>
        /// <returns></returns>
        private static int GetLineNum()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileLineNumber();
        }
        /// <summary>
        /// 取当前源码的源文件名
        /// </summary>
        /// <returns></returns>
        private static string GetCurSourceFileName()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileName();
        }
    }
}
