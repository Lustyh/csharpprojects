﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Shopfloor_Servers
{
    class Shopfloor
    {
        // private static SqlConnection SMT_DB = new SqlConnection(), FATP_SELDB = new SqlConnection(), FATP_SEL2DB = new SqlConnection(), FATP_SEL = new SqlConnection(), FATP_SEL2 = new SqlConnection() ,FATP_SEL_BK = new SqlConnection(), FATP_SEL2_BK = new SqlConnection();
        private static string FATP_Server, FATP_Server2, SMT_Server;
        private static bool check_DB = true, check_sel2_db = true;
        private static string BU = "NB4";
        /// <summary>
        /// Ini shopfloor, connect QMS DB server
        /// </summary>
        public static void IniShopfloor()
        {
            FATP_Server = GetConfigValue.FATP_DBserver1;
            FATP_Server2 = GetConfigValue.FATP_DBserver2;
            SMT_Server = GetConfigValue.SMT_DBserver;
            // Connect(SMT_DB, "server=" + GetConfigValue.SMT_DBserver + ";Database=" + GetConfigValue.SMT_DBname + ";Uid=execuser;Pwd=exec7*user;Integrated Security=False");
            // Connect(FATP_SELDB, "server=" + GetConfigValue.FATP_DBserver1 + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
            // Connect(FATP_SEL2DB, "server=" + GetConfigValue.FATP_DBserver2 + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
        }

        /// <summary>
        /// Connect QMS DB server
        /// </summary>
        /// <param name="sqlConnection"> sql connection variable </param>
        /// <param name="ConnectionString"> connection str </param>
        private static SqlConnection Connect(string ConnectionString)
        {
            SqlConnection sqlConnection = new SqlConnection();
            sqlConnection.ConnectionString = ConnectionString;
            try
            {
                sqlConnection.Open();
                return sqlConnection;
            }
            catch (Exception errorConDB)
            {
                RecordLog.WriLogError("[" + RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + errorConDB.Message, "errorConDB");
                Console.WriteLine("[" +RecordLog.GetTimeForDB() + "]" + GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + errorConDB.Message);
            }
            return null;
        }

        public static string DBInfo_OPID(string ID, string step, string Inputstring)
        {
            SqlConnection sqlConnection = new SqlConnection();
            RecordLog.WriLogTxt(Inputstring, step, ID);
            sqlConnection = Connect("server=" + FATP_Server2 + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
            string response = Connect_DB(sqlConnection, GetConfigValue.FATP_Interface1, "NB4", "", step, Inputstring);
            RecordLog.WriLogTxt(response, step + "_response", ID);
            return response;
        }

        /// <summary>
        /// SMT DB connect Interface
        /// </summary>
        /// <param name="station"> request station id </param>
        /// <param name="step"> step (request/handshake) </param>
        /// <param name="Inputstring"> Input str </param>
        /// <returns> QMS resposne </returns>
        public static string DBInfo_SMT(string SN ,string station, string step, string Inputstring, string strMD5, string SFCstation)//同SF交换过站信息
        {
#if QMB
                    BU = "QMB";
#endif
            SqlConnection sqlConnection = new SqlConnection();
            RecordLog.WriLogTxt(Inputstring, step, SN);
            string InputTime = RecordLog.GetTimeForDB();
            string Table_Name = "QueryDataLog";
            if (step == "handshake") Table_Name = "QDWLog";
            string Response = "";
            sqlConnection = Connect("server=" + SMT_Server + ";Database=" + GetConfigValue.SMT_DBname + ";Uid=execuser;Pwd=exec7*user;Integrated Security=False");
            
            if (sqlConnection.State == ConnectionState.Open)
            {
                Response = Connect_DB(sqlConnection, GetConfigValue.SMT_Interface, BU, station, step, Inputstring);
                RecordLog.WriLogTxt(Response, step + "_response", SN);
                RecordLog.SavaSFCToDB(strMD5, SN, SFCstation, Table_Name, step, Inputstring, InputTime, Response, RecordLog.GetTimeForDB(), GetDBServerIP(sqlConnection));
                return Response;
            }
            Connect("server=" + SMT_Server + ";Database=" + GetConfigValue.SMT_DBname + ";Uid=execuser;Pwd=exec7*user;Integrated Security=False");
            Response = Connect_DB(sqlConnection, GetConfigValue.SMT_Interface, BU, station, step, Inputstring);
            RecordLog.WriLogTxt(Response, step + "_response", SN);
            RecordLog.SavaSFCToDB(strMD5, SN, SFCstation, Table_Name, step, Inputstring, InputTime, Response, RecordLog.GetTimeForDB(), GetDBServerIP(sqlConnection));
            return Response;
        }

        /// <summary>
        /// FATP DB connect Interface
        /// </summary>
        /// <param name="station"> request station id </param>
        /// <param name="step">step (querydata/QDW)</param>
        /// <param name="Inputstring"> Input str </param>
        /// <param name="SFType"> SEL/SEL2 </param>
        /// <returns> QMS resposne </returns>
        public static string DBInfo_FATP(string SN ,string station, string step, string Inputstring, string SFType, string strMD5, string SFCstation)//同SF交换过站信息
        {
            SqlConnection sqlConnection = new SqlConnection();
            string FATP_Interface = GetConfigValue.FATP_Interface1;
            string InputTime = RecordLog.GetTimeForDB();
            string Table_Name = "QueryDataLog";
            if (step == "QDW") Table_Name = "QDWLog";
            RecordLog.WriLogTxt(Inputstring, step, SN);
            if (SFType == "SEL2")
            {
                sqlConnection = Connect("server=" + FATP_Server2 + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
                FATP_Interface = GetConfigValue.FATP_Interface2;
            }
            else
            {
                sqlConnection = Connect("server=" + FATP_Server + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
            }
            string Response = "";
            if (sqlConnection.State == ConnectionState.Open)
            {
                Response = Connect_DB(sqlConnection, FATP_Interface, "NB4", station, step, Inputstring);
                RecordLog.WriLogTxt(Response, step + "_response", SN);
                RecordLog.SavaSFCToDB(strMD5, SN, SFCstation, Table_Name, step, Inputstring, InputTime, Response, RecordLog.GetTimeForDB(), GetDBServerIP(sqlConnection));
                return Response;
            }
            sqlConnection = Change_DB(SFType);
            Response = Connect_DB(sqlConnection, FATP_Interface, "NB4", station, step, Inputstring);
            RecordLog.WriLogTxt(Response, step + "_response", SN);
            RecordLog.SavaSFCToDB(strMD5, SN, SFCstation, Table_Name, step, Inputstring, InputTime, Response, RecordLog.GetTimeForDB(), GetDBServerIP(sqlConnection));
            
            return Response;
            
        }

        /// <summary>
        /// Connect DB and get QMS data
        /// </summary>
        /// <param name="sqlConnection"> DB server </param>
        /// <param name="Interface"> Interface(MonitorPortal/MonitorPortal_SEL2) </param>
        /// <param name="BU"> FATP(NB4) SMT(NB4/QMB) </param>
        /// <param name="station"> request station id </param>
        /// <param name="step"> step(FATP[ querydata, QDW ] SMT[request, handshake]) </param>
        /// <param name="Inputstring"> Input str</param>
        /// <returns> QMS resposne </returns>
        private static string Connect_DB(SqlConnection sqlConnection, string Interface, string BU, string station, string step, string Inputstring)
        {
            try
            {
                SqlCommand b = new SqlCommand(Interface, sqlConnection);
                b.CommandType = CommandType.StoredProcedure;
                b.Parameters.Add("@BU", SqlDbType.VarChar).Value = BU;
                b.Parameters.Add("@Station", SqlDbType.VarChar).Value = station;
                b.Parameters.Add("@Step", SqlDbType.VarChar).Value = step;
                b.Parameters.Add("@InPutStr", SqlDbType.VarChar).Value = Inputstring;
                b.Parameters.Add("@OutPutStr", SqlDbType.VarChar, 8000);
                b.Parameters["@BU"].Direction = ParameterDirection.Input;
                b.Parameters["@BU"].DbType = DbType.String;
                b.Parameters["@Station"].Direction = ParameterDirection.Input;
                b.Parameters["@Station"].DbType = DbType.String;
                b.Parameters["@Step"].Direction = ParameterDirection.Input;
                b.Parameters["@Step"].DbType = DbType.String;
                b.Parameters["@InPutStr"].Direction = ParameterDirection.Input;
                b.Parameters["@InPutStr"].DbType = DbType.String;
                b.Parameters["@OutPutStr"].DbType = DbType.String;
                b.Parameters["@OutPutStr"].Direction = ParameterDirection.Output;
                b.ExecuteScalar();
                string ss = (string)b.Parameters["@OutPutStr"].Value;
                sqlConnection.Close();
                return ss;
            }
            catch (Exception error_sql)
            {
                RecordLog.WriLogError(GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_sql.Message, "error_sql");
                return GetCurSourceFileName() + ":" + GetLineNum().ToString() + " " + error_sql.Message;
            }
        }

        /// <summary>
        /// If DB server stop work, it will auto change the DB server
        /// </summary>
        /// <param name="SFType">  SEL/SEL2  </param>
        /// <returns> return the replaced SQL variable </returns>
        private static SqlConnection Change_DB(string SFType)
        {
            SqlConnection sqlConnection = new SqlConnection();
            if (SFType == "SEL2")
            {
                if (check_DB)
                {
                    FATP_Server2 = GetConfigValue.FATP_DBserver2_BK;
                    sqlConnection = Connect("server=" + FATP_Server2 + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
                    check_DB = false;
                }
                else
                {
                    FATP_Server2 = GetConfigValue.FATP_DBserver2;
                    sqlConnection = Connect("server=" + FATP_Server2 + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
                    check_DB = true;
                }
                return sqlConnection;
            }
            else
            {
                if (check_sel2_db)
                {
                    FATP_Server = GetConfigValue.FATP_DBserver1_BK;
                    sqlConnection = Connect("server=" + FATP_Server + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
                    check_sel2_db = false;
                }
                else
                {
                    FATP_Server = GetConfigValue.FATP_DBserver1;
                    sqlConnection = Connect("server=" + FATP_Server + ";Database=" + GetConfigValue.FATP_DBname + ";Uid=sdt;Pwd=SDT#7;Integrated Security=False");
                    check_sel2_db = false;
                }
                return sqlConnection;
            }
        }

        /// <summary>
        /// get key value
        /// </summary>
        /// <param name="name"> keys </param>
        /// <param name="separation"> separate str </param>
        /// <param name="str_sample"> total string </param>
        /// <returns> return value </returns>
        public static string Get_str(string name, string separation, string str_sample)
        {
            try
            {
                string Get_1, Get_2, Get_3, Get_4, Get_5;
                int Get_n_1, Get_n_2, Get_n_3, Get_n_4, Get_n_5;
                Get_1 = name.ToUpper();
                Get_2 = separation.ToUpper();
                Get_3 = str_sample;
                Get_n_4 = Get_3.IndexOf(Get_1);
                Get_n_5 = Get_3.IndexOf(Get_2);
                if (Get_n_4 > -1)
                { }

                if (Get_n_5 > -1) { } else { }

                Get_4 = Get_3.Substring(Get_3.ToUpper().IndexOf(Get_1));

                Get_n_1 = Get_1.Length;
                Get_n_2 = Get_2.Length;
                Get_n_3 = Get_4.ToUpper().IndexOf(Get_2);
                Get_5 = Get_3.Substring(Get_3.ToUpper().IndexOf(Get_1) + Get_n_1, Get_n_3 - Get_n_1);
                return Get_5;
            }
            catch (Exception)
            {
                return "";
            }
        }
        /// <summary>
        /// get DB server IP
        /// </summary>
        /// <param name="sqlConnection">sqlConnection</param>
        /// <returns>IP</returns>
        private static string GetDBServerIP(SqlConnection sqlConnection)
        {
            try
            {
                return sqlConnection.ConnectionString.Split(';')[0].Split('=')[1];
            }
            catch (Exception)
            {
                return "";   
            }
        }

        /// <summary>
        /// 取得当前源码的哪一行
        /// </summary>
        /// <returns></returns>
        private static int GetLineNum()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileLineNumber();
        }
        /// <summary>
        /// 取当前源码的源文件名
        /// </summary>
        /// <returns></returns>
        private static string GetCurSourceFileName()
        {
            System.Diagnostics.StackTrace st = new System.Diagnostics.StackTrace(1, true);
            return st.GetFrame(0).GetFileName();
        }
    }
}
