﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QueryData
{
    public partial class Query : Form
    {
        public Query()
        {
            InitializeComponent();
        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            if (!groupBox1.Enabled)
                groupBox1.Enabled = true;
            else
                groupBox1.Enabled = false;
        }

        private void txtSn_KeyDown(object sender, KeyEventArgs e)
        {
            richTextBox2.Clear();
            if (e.KeyCode == Keys.Enter)
            {
                using (SqlConnection sf = new SqlConnection())
                {
                    try
                    {
                        sf.ConnectionString = string.Format(cbConn.Text, cbSer.Text, cbDB.Text, cbUser.Text, cbPwd.Text);
                        //info(sf.ConnectionString);
                        StringBuilder OutPutStr = new StringBuilder();
                        string input = string.Format(cbInput.Text, txtSn.Text);
                        info(input);
                        sf.Open();
                        if (sf.State == ConnectionState.Open)
                        {
                            SqlCommand sqlcmd = new SqlCommand(cbCmd.Text, sf);
                            sqlcmd.CommandType = CommandType.StoredProcedure;
                            sqlcmd.Parameters.Add("@BU", SqlDbType.VarChar).Value = cbBU.Text;
                            sqlcmd.Parameters.Add("@Station", SqlDbType.VarChar).Value = cbStation.Text;
                            sqlcmd.Parameters.Add("@Step", SqlDbType.VarChar).Value = cbStep.Text;
                            sqlcmd.Parameters.Add("@InPutStr", SqlDbType.VarChar).Value = input;
                            sqlcmd.Parameters.Add("@OutPutStr", SqlDbType.VarChar, 8000);
                            sqlcmd.Parameters["@BU"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@BU"].DbType = DbType.String;
                            sqlcmd.Parameters["@Station"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@Station"].DbType = DbType.String;
                            sqlcmd.Parameters["@Step"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@Step"].DbType = DbType.String;
                            sqlcmd.Parameters["@InPutStr"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@InPutStr"].DbType = DbType.String;
                            sqlcmd.Parameters["@OutPutStr"].DbType = DbType.String;
                            sqlcmd.Parameters["@OutPutStr"].Direction = ParameterDirection.Output;
                            sqlcmd.ExecuteScalar();
                            OutPutStr.Append(sqlcmd.Parameters["@OutPutStr"].Value.ToString());
                            if (sf.State == ConnectionState.Open) sf.Close();
                            info(OutPutStr.ToString());
                            richTextBox2.Clear();
                            string values = OutPutStr.ToString().Replace("\r", "\\r").Replace("\n", "\\n");
                            string[] key_v = values.Replace(";$;", "\n").Split('\n');
                            string country = "";
                            foreach(string line in key_v)
                            {
                                if (line.Contains("="))
                                {
                                    string[] data = line.Replace("SET ", "").Split('=');
                                    string n_line = string.Format("\"{0}\"=\"{1}\"\n", data[0], data[1]);
                                    richTextBox2.AppendText(n_line);
                                    if(data[0].ToUpper() == "COUNTRY")
                                    {
                                        country = data[1];
                                    }
                                }
                            }
#if SHOW_COUNTRY
                            richTextBox1.Clear();
                            richTextBox1.Font = new Font("Arial", 160);
                            richTextBox1.AppendText(country);
#endif
                        }
                        else info("Connect Fail!");
                    }
                    catch (Exception x)
                    {
                        sf.Close();
                        info(x.Message);
                    }
                }
                txtSn.Clear();
            }
        }

        private void info(string msg)
        {
            string txt = DateTime.Now.ToString("[HH:mm:ss]") + msg + "\n";
            richTextBox1.AppendText(txt);
        }

        private void PreSet(object sender, EventArgs e)
        {
            string key = cbFct.Text + cbType.Text;
            Dictionary<string, string[]> map = new Dictionary<string, string[]>();
            
            string[] qmbfatp = {
                "server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False",
                "10.97.1.40","QMS","sdt","SDT#7",
                "SN={0};$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;",
                "MonitorPortal","NB4","SWDL","querydata",
            };
            string[] qmbsmt = {
                "server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False",
                "10.97.2.11","SMT","execuser","exec7*user",
                "MB_NUM={0}",
                "MonitorPortal","QMB","MLBRouting","request",
            };
            string[] qmbskip = {
                "server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False",
                "10.97.1.40","QMS","sdt","SDT#7",
                "MASTER:SN={0};*;MASTER:STATION=FATP-PROV-02;*;MASTER:ERRORCODE=PASS;*;MASTER:TOTALERRORCODE=PASS;*;MASTER:FPYCODE=PASS;*;MASTER:OTPKEY=;*;MASTER:DeviceSN=;*;MASTER:BTMAC=;*;MASTER:BSSID_MAC=;*;MASTER:WLMAC=;*;MASTER:PRO_QRCODE=;*;MASTER:MonitorAgentVer=VW20151102.01;*;",
                "MonitorPortal","NB4","FATP-PROV-02","QDW",
            };
            string[] qcmcfatp = {
                "server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False",
                "10.18.6.52","QMS","sdt","SDT#7",
                "SN={0};$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;",
                "MonitorPortal","NB4","SWDL","querydata",
            };
            string[] qcmcnhc = {
                "server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False",
                "10.18.6.52","QMS","sdt","SDT#7",
                "SN={0};$;station=QueryData;$;MonitorAgentVer=VW20151102.01;$;",
                "MonitorPortal_SEL2","NB4","SWDL","querydata",
            };
            string[] qcmcsmt = {
                "server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False",
                "10.18.8.11","SMT","execuser","exec7*user",
                "MB_NUM={0}",
                "MonitorPortal","NB4","MLBRouting","request",
            };

            map["QMBSMT"]   = qmbsmt;
            map["QMBFATP-SEL"]  = qmbfatp;
            map["QMBFATP-SEL2"]   = qmbfatp;
            map["QMBSKIP"] = qmbskip;
            map["QCMCFATP-SEL"] = qcmcfatp;
            map["QCMCFATP-SEL2"]  = qcmcnhc;
            map["QCMCSMT"]  = qcmcsmt;
            if (map.ContainsKey(key))
            {
                string[] v = map[key];
                cbConn.Text    = v[0];
                cbSer.Text     = v[1];
                cbDB.Text      = v[2];
                cbUser.Text    = v[3];
                cbPwd.Text     = v[4];
                cbInput.Text   = v[5];
                cbCmd.Text     = v[6];
                cbBU.Text      = v[7];
                cbStation.Text = v[8];
                cbStep.Text    = v[9];
            }
        }

        private void Query_Load(object sender, EventArgs e)
        {
            cbFct.Items.AddRange("QCMC\nQMB".Split('\n'));
            cbType.Items.AddRange("FATP-SEL\nSMT\nFATP-SEL2\nSKIP".Split('\n'));
            cbInput.Items.AddRange(("SN={0};$;station=QueryData;$;"
                +"\nSN={0};$;station=QueryData;$;NextStation=FLASH_IMAGE;$;"
                +"\nMB_NUM={0}\nMB_NUM={0};$;station=QueryData;$;"
                + "\nMASTER:SN={0};*;MASTER:HOLDFLAG=Y;*;MASTER:HOLDSTATION=FATP-PROV;*;MASTER:REASON=For_FATP-GOLDEN-TEST;*;"
                + "\nMASTER:SN={0};*;MASTER:STATION=FATP-PROV-02;*;MASTER:ERRORCODE=PASS;*;MASTER:TOTALERRORCODE=PASS;*;MASTER:FPYCODE=PASS;*;MASTER:OTPKEY=;*;MASTER:DeviceSN=;*;MASTER:BTMAC=;*;MASTER:BSSID_MAC=;*;MASTER:WLMAC=;*;MASTER:PRO_QRCODE=;*;MASTER:MonitorAgentVer=VW20151102.01;*;"
                ).Split('\n'));
            cbConn.Items.AddRange("server={0};Database={1};Uid={2};Pwd={3};Integrated Security=False".Split('\n'));
            cbSer.Items.AddRange("10.18.8.11\n10.18.6.52\n10.97.1.40\n10.97.2.11".Split('\n'));
            cbDB.Items.AddRange("QMS\nSMT".Split('\n'));
            cbCmd.Items.AddRange("MonitorPortal\nMonitorPortal_SEL2".Split('\n'));
            cbBU.Items.AddRange("NB4\nQMB\nSEL_Test".Split('\n'));
            cbUser.Items.AddRange("sdt\nexecuser".Split('\n'));
            cbPwd.Items.AddRange("SDT#7\nexec7*user".Split('\n'));
            cbStation.Items.AddRange("SWDL\nMLBRouting\nFATP-PROV".Split('\n'));
            cbStep.Items.AddRange("querydata\nrequest\nQDW".Split('\n'));
#if SHOW_COUNTRY
            cbType.Enabled = false;
            btnSet.Enabled = false;
            cbFct.Enabled = false;
#endif
        }
    }
}
