﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SFVarCheck
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Thread(go).Start();

        }


        private void go()
        {
            string[] vars = textBox1.Text.Split(',');
            string[] sns = richTextBox1.Text.Split('\n');
            foreach(string sn in sns)
            {
                if(sn.Trim().Length == 0)
                {
                    continue;
                }
                using (SqlConnection sf = new SqlConnection())
                {
                    try
                    {
                        sf.ConnectionString = "server=10.97.1.40;Database=QMS;Uid=sdt;Pwd=SDT#7;Integrated Security=False";//string.Format(cbConn.Text, cbSer.Text, cbDB.Text, cbUser.Text, cbPwd.Text);
                        richTextBox2.AppendText(sf.ConnectionString);
                        StringBuilder OutPutStr = new StringBuilder();
                        string input = string.Format("SN={0};$;station=querydata;$;", sn.Trim());
                        richTextBox2.AppendText(input);
                        sf.Open();
                        if (sf.State == ConnectionState.Open)
                        {
                            SqlCommand sqlcmd = new SqlCommand("MonitorPortal", sf);
                            sqlcmd.CommandType = CommandType.StoredProcedure;
                            sqlcmd.Parameters.Add("@BU", SqlDbType.VarChar).Value = "NB4";
                            sqlcmd.Parameters.Add("@Station", SqlDbType.VarChar).Value = "SWDL";
                            sqlcmd.Parameters.Add("@Step", SqlDbType.VarChar).Value = "querydata";
                            sqlcmd.Parameters.Add("@InPutStr", SqlDbType.VarChar).Value = input;
                            sqlcmd.Parameters.Add("@OutPutStr", SqlDbType.VarChar, 8000);
                            sqlcmd.Parameters["@BU"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@BU"].DbType = DbType.String;
                            sqlcmd.Parameters["@Station"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@Station"].DbType = DbType.String;
                            sqlcmd.Parameters["@Step"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@Step"].DbType = DbType.String;
                            sqlcmd.Parameters["@InPutStr"].Direction = ParameterDirection.Input;
                            sqlcmd.Parameters["@InPutStr"].DbType = DbType.String;
                            sqlcmd.Parameters["@OutPutStr"].DbType = DbType.String;
                            sqlcmd.Parameters["@OutPutStr"].Direction = ParameterDirection.Output;
                            sqlcmd.ExecuteScalar();
                            OutPutStr.Append(sqlcmd.Parameters["@OutPutStr"].Value.ToString());
                            if (sf.State == ConnectionState.Open) sf.Close();
                            richTextBox2.AppendText(OutPutStr.ToString());
                            
                            string values = OutPutStr.ToString().Replace("\r", "\\r").Replace("\n", "\\n");
                            string[] key_v = values.Replace(";$;", "\n").Split('\n');
                            string country = "";
                            foreach (string k in vars)
                            {
                                bool have_value = false;
                                foreach (string line in key_v)
                                {
                                    if (line.Contains("="))
                                    {
                                        string[] data = line.Replace("SET ", "").Split('=');
                                        string n_line = string.Format("\"{0}\"=\"{1}\"\n", data[0], data[1]);
                                        if (data[0].ToUpper() == "COUNTRY")
                                        {
                                            country = data[1];
                                        }
                                        if(data[0] == k && data[1].Trim().Length > 0)
                                        {
                                            have_value = true;
                                        }
                                    }
                                }
                                if (!have_value)
                                {
                                    richTextBox3.AppendText(sn.Trim() + " key:" + k + "\n");
                                }
                            }

                        }
                        else richTextBox2.AppendText("Connect Fail!");
                    }
                    catch (Exception x)
                    {
                        sf.Close();
                        richTextBox2.AppendText(x.Message);
                    }
                }
            }
        }
    }
}
