# QueryData

this tool is used for querydata from shopfloor for both QMB and QCMC